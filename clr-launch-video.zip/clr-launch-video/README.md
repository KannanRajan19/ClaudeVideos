# CLR Pro launch video generator

Turns ten CLR Pro screenshots into the 78-second motion-graphics launch video (1920×1080, 30 fps, H.264 + AAC) with its original soundtrack.

- **Same look every time:** the animation, typography (fonts are bundled), transitions, highlight pop-outs, cursor moves, music and sound effects are all code, so every render comes out the same.
- **What you supply:** only the screenshots and the positions of a few things on them (for example, where the Go button is).
- **Screenshots stay local:** they never leave `screens/`, which is git-ignored.

```
config/screens.json     which file is which screen + named regions on each (fractions of the image)
config/storyboard.json  every word shown on screen
launchvideo/            renderer (engine, scenes, music, CLI)
tools/annotate.html     point-and-drag editor for the regions
fonts/                  Inter + Playfair Display (SIL Open Font License)
screens/                your screenshots go here (git-ignored)
output/                 renders, previews, checks (git-ignored)
```

## 1. Set up (once)

You need Python 3.10+ and ffmpeg on your PATH (`ffmpeg -version` should work). Alternatively, set an `FFMPEG` environment variable to the path of ffmpeg.exe.

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows   (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
```

## 2. Capture the screenshots

Use Snagit (or Win+Shift+S) at **100 % browser zoom**, save as **PNG**, and crop exactly as described below. Higher resolution gives a sharper video: screenshots are scaled *down* into the frame, never up.

| File in `screens/` | What to capture |
|---|---|
| `tasks.png` | Task list (CTS Tasks) page. Web page area only, from the CLR Pro banner down to the bottom of the table. No browser tabs, address bar or taskbar. |
| `history.png` | The **Review history** dialog only (the white card). |
| `review.png` | CL Review page. From the dark CTS Tasks / CL Review button bar down to the bottom of the table. |
| `thread.png` | The **Comment Thread** dialog only. |
| `reuse.png` | CL Review page (same framing as `review.png`) with **Comment found on another aircraft** open. |
| `general.png` | The **General Comment** dialog only. |
| `mine.png` | **Show My Comments** page, same framing as `review.png`. |
| `heatmap.png` | Heatmap page. From the CTS Tasks bar to the bottom of the treemap, with the tooltip for the largest block showing. |
| `email.png` | The **Reviewer Pending Email** dialog only. |
| `clara.png` | The **Clara** panel only, from its header down to the "Ask Clara about…" input. |

These descriptions are also stored per screen in `config/screens.json` (`capture`) and shown in the region editor.

## 3. Line up the regions

Each screen has a few named regions: the areas that get lifted out, highlighted, clicked or turned into a transition. They are stored as fractions of the image, so they carry over between resolutions. They still need a quick check whenever your framing differs.

```bash
python -m launchvideo check
```

This writes `output/check/<screen>.png` with every region drawn on your screenshot. If a box is off:

1. Open `tools/annotate.html` in Chrome or Edge. It works offline, and nothing is uploaded.
2. Load `config/screens.json`, then load your screenshots. They are matched to screens by file name.
3. Click a region on the left, then drag on the image to redraw it. Drag inside the box to move it. Arrow keys nudge it; hold Shift for 10 px steps.
4. Click **Download screens.json**, replace `config/screens.json` with it, and run `check` again.

<details><summary>What each region is for</summary>

| Screen | Region | Used for |
|---|---|---|
| tasks | `status_filters` | All / Offboarded / Scheduled / Released chips (lifted out) |
| | `signoff_columns` | SIGNOFF + STRUCTURES SIGNOFF columns, header + ~7 rows (lifted out) |
| | `history_icon` | history icon the cursor clicks (circle transition starts here) |
| | `go_button` | one **Go** button (it grows into the CL Review scene) |
| | `ask_clara` | **Ask Clara** button (it grows into the Clara scene) |
| history | `row_1`…`row_6` | one box per department row (ticked in sequence) |
| review | `context_bar` | the dark AC / Task ID / GDL / Baseline strip (lifted out) |
| | `baseline_columns` | BASELINE / IN BL? / CHAT header + ~10 rows (lifted out) |
| | `no_flag` | a red **No** inside `baseline_columns` (pulses red) |
| | `filter_chips`, `chip_1`…`chip_9` | the review-state chip row, and each chip (highlight steps across) |
| | `chat_icon` | chat bubble the cursor clicks (circle transition starts here) |
| thread | `dept_tabs`, `tab_1`…`tab_6` | department tab row and each tab |
| | `message_1`…`message_3` | the comment and two replies (revealed one by one) |
| | `bottom_bar` | Accepted / Cert Guidance / Send row (lifted out) |
| reuse | `dialog` | the "Comment found on another aircraft" dialog (pops forward) |
| | `aircraft_tag`, `use_button` | callout anchor, and the button that is clicked |
| general | `comment_placeholder` | the placeholder line where the typing appears |
| | `create_button` | Create button (clicked) |
| mine | `responses_columns`, `task_columns` | the two lifted-out column groups |
| heatmap | `hot_1`…`hot_3` | the three largest blocks (highlighted in turn) |
| | `tooltip`, `tooltip_bars` | the tooltip card, and its bar area (bars grow in) |
| email | `subject_row`, `send_button` | lifted-out subject row, and the Send button |
| clara | `suggestion_1`…`suggestion_6` | suggestion chips (pop in one by one) |
| | `bubble_background` | a plain patch inside the message bubble (used to hide chips before they pop in) |
</details>

## 4. Preview, then render

```bash
python -m launchvideo preview                 # output/preview.png, 22 key frames in a few seconds
python -m launchvideo still 27.2              # one full-size frame at 27.2 s
python -m launchvideo render --max-mb 18      # full video
```

`render` writes `output/clr_pro_launch_master.mp4` (high quality). With `--max-mb`, it also writes `output/clr_pro_launch.mp4` under that size. Use 18 for email: Outlook and Gmail cap attachments at 20–25 MB, and encoding adds about a third to the file size. It uses every CPU core. Expect about 15 minutes on a 2-core machine and much less on a modern workstation.

Useful options:

- `--start 22 --end 32`: render just part of the video.
- `--workers N`: limit the number of CPU cores used.
- `--crf 14`: an even higher-quality master.
- `--no-music`: leave out the soundtrack.
- `python -m launchvideo music`: write only `output/score.wav`.

## Changing the words

Edit `config/storyboard.json`. It holds the intro and tagline, department names, each chapter's number and title, headline and sub lines, callout labels, the text typed into the General Comment box, the outro words, the end line ("Coming soon") and the credit. Keep headlines short (about 16 characters per line) so they fit beside the screenshots. Run `preview` to check.

Timing, camera moves and effects are in `launchvideo/scenes.py`. Every scene is one function, and all times are absolute seconds. The music is timed to the same cue sheet (`build_cues()`), so if you move a scene, move its cues too.

## Notes

- **Fonts:** Inter and Playfair Display, licensed under the SIL Open Font License (see `fonts/OFL-*.txt`).
- **Music:** synthesized by `launchvideo/music.py`. There are no samples and no third-party audio.
- **Screenshots:** `.gitignore` keeps `screens/` and `output/` out of the repo. Don't commit screenshots or renders: they contain internal data.
