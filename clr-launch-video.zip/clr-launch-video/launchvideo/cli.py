"""Command line: python -m launchvideo {check,preview,still,music,render} [options]"""
import argparse
import os
import shutil
import subprocess
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .config import ROOT, Screens, load_story
from . import scenes
from .engine import W, H, FPS, FONT_DIR

OUT = ROOT / 'output'
PREVIEW_TIMES = [2.9, 9.5, 13.2, 15.3, 20.6, 25.2, 27.2, 29.3, 34.2, 36.0, 39.5, 41.8,
                 44.8, 48.8, 51.0, 54.4, 57.0, 62.2, 66.8, 68.2, 71.0, 75.5]


# ---------------------------------------------------------------- helpers
def _load(args):
    screens = Screens(args.screens, ROOT)
    story = load_story(args.story)
    return screens, story


def _need_screens(screens):
    miss = screens.missing()
    if miss:
        print('Missing screenshots:')
        for k in miss:
            print(f'  {k:8s} -> {screens.file(k)}\n           {screens.cfg[k].get("capture", "")}')
        sys.exit(1)


def _ffmpeg():
    exe = os.environ.get('FFMPEG') or shutil.which('ffmpeg')
    if not exe:
        sys.exit('ffmpeg not found. Install it (https://ffmpeg.org) and put it on PATH, or set the FFMPEG environment variable.')
    return exe


def _init_worker(screens_path, story_path):
    scenes.init(Screens(screens_path, ROOT), load_story(story_path))


def _frame(i):
    return scenes.render(i / FPS).tobytes()


# ---------------------------------------------------------------- commands
def cmd_check(args):
    """Draw every named region on its screenshot so you can see if it lines up."""
    screens, _ = _load(args)
    out = OUT / 'check'; out.mkdir(parents=True, exist_ok=True)
    try: fnt = ImageFont.truetype(str(FONT_DIR / 'inter600.ttf'), 16)
    except Exception: fnt = ImageFont.load_default()
    colors = [(0, 200, 140), (255, 90, 90), (70, 140, 255), (255, 170, 0), (190, 90, 255), (0, 190, 220)]
    ok = True
    for key in screens.keys():
        if not screens.file(key).exists():
            print(f'  MISSING  {key:8s} {screens.file(key)}'); ok = False; continue
        img = Image.fromarray(screens.image(key)).convert('RGB')
        w, h = img.size
        d = ImageDraw.Draw(img, 'RGBA')
        for i, (name, (x0, y0, x1, y1)) in enumerate(screens.cfg[key]['regions'].items()):
            c = colors[i % len(colors)]
            box = (x0 * w, y0 * h, x1 * w, y1 * h)
            d.rectangle(box, outline=c + (255,), width=max(2, w // 800), fill=c + (40,))
            tw = d.textlength(name, font=fnt)
            ty = max(0, box[1] - 20)
            d.rectangle((box[0], ty, box[0] + tw + 8, ty + 20), fill=c + (230,))
            d.text((box[0] + 4, ty + 1), name, font=fnt, fill=(255, 255, 255))
        if w > 1800: img = img.resize((1800, int(h * 1800 / w)), Image.LANCZOS)
        p = out / f'{key}.png'; img.save(p)
        print(f'  ok       {key:8s} {w}x{h}  -> {p}')
    print('\nOpen the images in output/check/. If a box is off, fix it with tools/annotate.html.' if ok else
          '\nAdd the missing screenshots (see README), then run check again.')


def cmd_preview(args):
    screens, story = _load(args); _need_screens(screens)
    scenes.init(screens, story)
    times = [float(x) for x in args.times.split(',')] if args.times else PREVIEW_TIMES
    t0 = time.time()
    ims = [Image.fromarray(scenes.render(t)) for t in times]
    cols, w, h = 3, 640, 360
    sheet = Image.new('RGB', (cols * w + (cols - 1) * 6, ((len(ims) + cols - 1) // cols) * (h + 6)), (60, 60, 60))
    for i, (t, im) in enumerate(zip(times, ims)):
        th = im.resize((w, h), Image.LANCZOS); ImageDraw.Draw(th).text((6, 4), f'{t:.1f}s', fill=(255, 255, 0))
        sheet.paste(th, ((i % cols) * (w + 6), (i // cols) * (h + 6)))
    OUT.mkdir(exist_ok=True)
    p = OUT / 'preview.png'; sheet.save(p)
    print(f'{len(times)} frames in {time.time() - t0:.0f}s -> {p}')


def cmd_still(args):
    screens, story = _load(args); _need_screens(screens)
    scenes.init(screens, story)
    OUT.mkdir(exist_ok=True)
    p = OUT / f'still_{args.t:.2f}.png'
    Image.fromarray(scenes.render(args.t)).save(p); print(p)


def cmd_music(args):
    screens, story = _load(args)
    scenes.init(screens, story)
    from .music import make_score
    OUT.mkdir(exist_ok=True)
    p = make_score(list(scenes.SFX), OUT / 'score.wav', scenes.DUR); print(p)


def cmd_render(args):
    screens, story = _load(args); _need_screens(screens)
    ff = _ffmpeg()
    scenes.init(screens, story)
    OUT.mkdir(exist_ok=True)
    wav = OUT / 'score.wav'
    if not args.no_music:
        from .music import make_score
        print('Generating music...'); make_score(list(scenes.SFX), wav, scenes.DUR)
    start, end = args.start, min(args.end or scenes.DUR, scenes.DUR)
    f0, f1 = int(round(start * FPS)), int(round(end * FPS))
    out = Path(args.out)
    master = out.with_name(out.stem + '_master.mp4') if args.max_mb else out
    cmd = [ff, '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-']
    if not args.no_music: cmd += ['-ss', f'{start:.3f}', '-i', str(wav)]
    cmd += ['-vf', 'scale=out_color_matrix=bt709:out_range=tv', '-c:v', 'libx264', '-preset', 'slow', '-crf', str(args.crf),
            '-pix_fmt', 'yuv420p', '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709']
    if not args.no_music: cmd += ['-c:a', 'aac', '-b:a', '256k', '-shortest']
    cmd += ['-movflags', '+faststart', str(master)]
    workers = args.workers or max(1, (os.cpu_count() or 2))
    print(f'Rendering {f1 - f0} frames ({start:.1f}-{end:.1f}s) with {workers} worker(s)...')
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE); t0 = time.time()
    with Pool(workers, initializer=_init_worker, initargs=(str(screens.path), args.story)) as pool:
        for k, fr in enumerate(pool.imap(_frame, range(f0, f1), chunksize=4)):
            p.stdin.write(fr)
            if k % 150 == 0 and k:
                el = time.time() - t0
                print(f'  {k}/{f1 - f0} frames, {el:.0f}s elapsed, ~{el / k * (f1 - f0 - k):.0f}s left', flush=True)
    p.stdin.close(); p.wait()
    print(f'Wrote {master} ({master.stat().st_size / 1e6:.1f} MB) in {time.time() - t0:.0f}s')
    if args.max_mb:
        dur = end - start
        vk = int(args.max_mb * 8e6 / dur / 1000 * 0.93 - 160)   # MB = 10^6 bytes, with headroom
        common = [ff, '-y', '-loglevel', 'error', '-i', str(master), '-c:v', 'libx264', '-preset', 'slow', '-b:v', f'{vk}k']
        log = str(OUT / 'ffmpeg2pass')
        subprocess.run(common + ['-pass', '1', '-passlogfile', log, '-an', '-f', 'mp4', os.devnull], check=True)
        subprocess.run(common + ['-maxrate', f'{int(vk * 2.2)}k', '-bufsize', f'{int(vk * 3.3)}k', '-pass', '2', '-passlogfile', log,
                                 '-pix_fmt', 'yuv420p', '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
                                 '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', str(out)], check=True)
        print(f'Wrote {out} ({out.stat().st_size / 1e6:.1f} MB, target {args.max_mb} MB)')


def main(argv=None):
    ap = argparse.ArgumentParser(prog='python -m launchvideo', description='Screenshots -> CLR Pro launch video')
    ap.add_argument('--screens', default=str(ROOT / 'config' / 'screens.json'))
    ap.add_argument('--story', default=str(ROOT / 'config' / 'storyboard.json'))
    sub = ap.add_subparsers(dest='cmd', required=True)
    sub.add_parser('check', help='overlay named regions on each screenshot (output/check/)')
    p = sub.add_parser('preview', help='contact sheet of key frames (output/preview.png)')
    p.add_argument('--times', help='comma-separated seconds, e.g. 13.2,27,57')
    p = sub.add_parser('still', help='one full-size frame'); p.add_argument('t', type=float)
    sub.add_parser('music', help='write output/score.wav')
    p = sub.add_parser('render', help='render the MP4')
    p.add_argument('--out', default=str(OUT / 'clr_pro_launch.mp4'))
    p.add_argument('--workers', type=int, default=0, help='parallel processes (default: all CPU cores)')
    p.add_argument('--start', type=float, default=0.0); p.add_argument('--end', type=float, default=0.0)
    p.add_argument('--crf', type=int, default=16, help='x264 quality for the master (lower = better/larger)')
    p.add_argument('--max-mb', type=float, default=0, help='also make a copy under this many MB (18 fits most email systems)')
    p.add_argument('--no-music', action='store_true')
    args = ap.parse_args(argv)
    {'check': cmd_check, 'preview': cmd_preview, 'still': cmd_still, 'music': cmd_music, 'render': cmd_render}[args.cmd](args)
