"""CLR Pro launch video generator: screenshots + config -> 78 s motion-graphics MP4."""
