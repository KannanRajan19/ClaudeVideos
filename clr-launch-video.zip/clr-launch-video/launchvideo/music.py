"""Original 120 BPM launch track + UI sound effects, synthesized with numpy (no samples, no licensing).
Deterministic: the same cue sheet always produces the same WAV."""
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, fftconvolve

SR = 48000
rng = np.random.default_rng(42)


def mtof(m): return 440.0 * 2 ** ((m - 69) / 12)
def tt(n): return np.arange(n) / SR
def noise(n): return rng.standard_normal(n)
def stereo(l, r): return np.column_stack([l, r])


# ---------------------------------------------------------------- oscillators / filters
def saw(f, n, phase0=None):
    f = np.broadcast_to(np.asarray(f, float), (n,))
    dt = f / SR
    ph = (np.cumsum(dt) + (rng.random() if phase0 is None else phase0)) % 1.0
    y = 2 * ph - 1
    m1 = ph < dt; x = ph[m1] / dt[m1]; y[m1] -= (x + x - x * x - 1)          # polyBLEP
    m2 = ph > 1 - dt; x = (ph[m2] - 1) / dt[m2]; y[m2] -= (x * x + x + x + 1)
    return y


def sine(f, n, phase0=0.0):
    f = np.broadcast_to(np.asarray(f, float), (n,))
    return np.sin(2 * np.pi * (np.cumsum(f) / SR) + phase0)


def filt(x, kind, fc, order=2):
    if kind == 'band': sos = butter(order, [max(20, fc[0]), min(SR * 0.45, fc[1])], 'band', fs=SR, output='sos')
    else: sos = butter(order, min(max(fc, 15), SR * 0.45), kind, fs=SR, output='sos')
    return sosfilt(sos, x)


def sweep(x, fc, kind='low', block=256, order=2, q_band=0.5):
    fc = np.broadcast_to(np.asarray(fc, float), (len(x),))
    y = np.empty_like(x); zi = None
    for b in range(0, len(x), block):
        c = float(fc[b])
        if kind == 'band':
            sos = butter(order, [max(30, c * (1 - q_band)), min(SR * 0.45, c * (1 + q_band))], 'band', fs=SR, output='sos')
        else:
            sos = butter(order, min(max(c, 20), SR * 0.45), kind, fs=SR, output='sos')
        if zi is None: zi = np.zeros((sos.shape[0], 2))
        y[b:b + block], zi = sosfilt(sos, x[b:b + block], zi=zi)
    return y


# ---------------------------------------------------------------- instruments
def sub_drop(f0=72, f1=27, dur=2.2, g=1.0):
    n = int(dur * SR); t = tt(n)
    return sine(f1 + (f0 - f1) * np.exp(-t / 0.45), n) * np.exp(-t / 0.9) * (1 - np.exp(-t / 0.004)) * g


def hat(dec=0.03):
    n = int(0.15 * SR); t = tt(n)
    return filt(noise(n), 'high', 7000) * np.exp(-t / dec)


def snare(dec=0.08):
    n = int(0.35 * SR); t = tt(n)
    return filt(noise(n), 'band', (900, 6000)) * np.exp(-t / dec) + sine(190 * (1 + 0.3 * np.exp(-t / 0.01)), n) * np.exp(-t / 0.05) * 0.6


def cymbal(dur=3.0, dec=0.9):
    n = int(dur * SR); t = tt(n)
    x = filt(noise(n), 'high', 3500) * np.exp(-t / dec) * (1 - np.exp(-t / 0.002))
    return x + filt(noise(n), 'band', (5000, 12000)) * np.exp(-t / (dec * 0.5)) * 0.5


def bass(m, dur=0.24, fc=600, dec=0.12):
    n = int(dur * SR); t = tt(n)
    v = saw(mtof(m), n) * 0.7 + np.sign(sine(mtof(m) / 2, n)) * 0.25 + sine(mtof(m) / 2, n) * 0.6
    v = filt(v, 'low', fc)
    e = (1 - np.exp(-t / 0.003)) * np.exp(-t / dec) * np.clip((dur - t) / 0.01, 0, 1)
    return np.tanh(v * e * 1.8)


def pad(notes, dur, att=1.2, rel=1.2, fc=1100, g=1.0):
    n = int(dur * SR); t = tt(n)
    L = np.zeros(n); R = np.zeros(n)
    for m in notes:
        for dc, side in ((-8, 0), (7, 1), (0, 2)):
            v = saw(mtof(m) * 2 ** (dc / 1200), n)
            if side == 0: L += v
            elif side == 1: R += v
            else: L += 0.6 * v; R += 0.6 * v
    L = filt(L, 'low', fc); R = filt(R, 'low', fc)
    e = np.clip(t / att, 0, 1) ** 2 * np.clip((dur - t) / rel, 0, 1)
    lfo = 1 + 0.08 * np.sin(2 * np.pi * 0.25 * t)
    k = g / (len(notes) * 2)
    return stereo(L * e * lfo * k, R * e * lfo * k)


def bell(m, dur=2.5, dec=0.9):
    n = int(dur * SR); t = tt(n); f = mtof(m)
    v = sine(f, n) * np.exp(-t / dec) + 0.4 * sine(f * 2.0, n) * np.exp(-t / (dec * 0.6)) \
        + 0.25 * sine(f * 2.76, n) * np.exp(-t / (dec * 0.35)) + 0.12 * sine(f * 5.4, n) * np.exp(-t / (dec * 0.15))
    return v * (1 - np.exp(-t / 0.002))


def riser(dur, f0=250, f1=7000, g=1.0):
    n = int(dur * SR); x = tt(n) / dur
    return sweep(noise(n), f0 * (f1 / f0) ** x, 'band', q_band=0.45) * (x ** 2.2) * 0.7 * g


def whoosh(dur=0.45, f0=6000, f1=300):
    n = int(dur * SR); x = tt(n) / dur
    return sweep(noise(n), f0 * (f1 / f0) ** x, 'band', q_band=0.6) * np.sin(np.pi * np.clip(x, 0, 1)) ** 1.5


def ui_click():
    n = int(0.05 * SR); t = tt(n)
    return sine(3400, n) * np.exp(-t / 0.003) + filt(noise(n), 'high', 2500) * np.exp(-t / 0.0015) * 0.6


def kick(g=1.0):
    n = int(0.45 * SR); t = tt(n)
    b = sine(45 + 110 * np.exp(-t / 0.035), n) * np.exp(-t / 0.22)
    c = filt(noise(n), 'high', 3000) * np.exp(-t / 0.004) * 0.25
    return np.tanh((b + c) * 1.8) * g


def clap():
    n = int(0.3 * SR); x = np.zeros(n)
    for d in (0.0, 0.011, 0.022):
        i = int(d * SR); m = n - i
        x[i:] += filt(noise(m), 'band', (1000, 3500)) * np.exp(-tt(m) / (0.01 if d < 0.02 else 0.09))
    return x


def pluck(m, dur=0.35, bright=4000):
    n = int(dur * SR); t = tt(n)
    v = saw(mtof(m), n) * 0.6 + np.sign(sine(mtof(m) * 1.002, n)) * 0.3
    v = sweep(v, 300 + bright * np.exp(-t / 0.06))
    return v * (1 - np.exp(-t / 0.002)) * np.exp(-t / 0.16)


def blip(f0, f1, dur=0.09):
    n = int(dur * SR); t = tt(n)
    return sine(f0 * (f1 / f0) ** (t / dur), n) * np.exp(-t / (dur * 0.35)) * (1 - np.exp(-t / 0.001))


def thud():
    n = int(0.2 * SR); t = tt(n)
    return sine(110 * (1 + 0.5 * np.exp(-t / 0.02)), n) * np.exp(-t / 0.06)


# ---------------------------------------------------------------- score
CHORDS = [  # (bass root, pad voicing, 16th arpeggio) : D - A - Bm - G
    (38, [50, 54, 57, 62], [74, 78, 81, 78, 74, 81, 78, 86]),
    (33, [49, 52, 57, 61], [73, 76, 81, 76, 73, 81, 76, 85]),
    (35, [50, 54, 59, 62], [74, 78, 83, 78, 74, 83, 78, 86]),
    (31, [50, 55, 59, 62], [74, 79, 83, 79, 74, 83, 79, 86]),
]


def make_score(sfx, path, dur=78.0):
    """Render the soundtrack for a cue sheet [(kind, time, gain)] to a 48 kHz stereo WAV."""
    global rng
    rng = np.random.default_rng(42)
    N = int(SR * dur)
    dryL, dryR, revL, revR = (np.zeros(N) for _ in range(4))
    padL, padR = np.zeros(N), np.zeros(N)

    def add(sig, t0, gain=1.0, pan=0.0, send=0.2):
        i0 = int(round(t0 * SR))
        if i0 >= N: return
        if i0 < 0: sig = sig[-i0:]; i0 = 0
        n = min(len(sig), N - i0)
        if sig.ndim == 1:
            a = (pan + 1) * np.pi / 4
            l, r = sig[:n] * np.cos(a) * gain, sig[:n] * np.sin(a) * gain
        else:
            l, r = sig[:n, 0] * gain, sig[:n, 1] * gain
        dryL[i0:i0 + n] += l; dryR[i0:i0 + n] += r
        revL[i0:i0 + n] += l * send; revR[i0:i0 + n] += r * send

    def add_pad(sig, t0, g):
        i0 = int(t0 * SR); n = min(len(sig), N - i0)
        if n > 0: padL[i0:i0 + n] += sig[:n, 0] * g; padR[i0:i0 + n] += sig[:n, 1] * g

    def section(t):
        if t < 5: return 'intro'
        if t < 11: return 'build'
        if t < 23: return 'groove'
        if t < 53: return 'full'
        if t < 61: return 'lift'
        if t < 69: return 'full'
        if t < 72.5: return 'outro_drive'
        return 'end'

    # intro (0-5): pad + pluck, riser into the beat
    add_pad(pad(CHORDS[0][1], 3.2, 1.2, 0.6, 1200), 0.0, 0.55)
    add_pad(pad(CHORDS[1][1], 2.3, 0.3, 0.3, 1600), 3.0, 0.5)
    for i, tb in enumerate(np.arange(1.0, 5.0, 0.25)):
        ch = CHORDS[0] if tb < 3.0 else CHORDS[1]; x = (tb - 1) / 4
        add(pluck(ch[2][i % 8], 0.3, 1200 + 3000 * x), tb, 0.10 + 0.05 * x, -0.4 if i % 2 else 0.4, 0.35)
    add(riser(1.6, 300, 8000), 3.4, 0.35, 0, 0.25)
    rc = cymbal(1.2, 0.5)[::-1]; add(stereo(rc, rc), 5.0 - len(rc) / SR, 0.12, 0, 0.3)

    # groove: bars start on odd seconds so scene changes land on downbeats
    kick_times = []
    for k in range(int((dur - 1) // 2) + 1):
        t0 = 1.0 + 2 * k
        if t0 < 5 or t0 >= 73: continue
        root, voicing, arp = CHORDS[k % 4]
        sec = section(t0)
        add_pad(pad(voicing, 2.05, 0.08, 0.15, 1500 if sec != 'lift' else 2200), t0, 0.42)
        for j in range(8):
            tj = t0 + j * 0.25
            if tj >= 72.5: break
            add(bass(root + (12 if j in (3, 6) else 0), 0.22, 900 if sec != 'build' else 600, 0.12), tj, 0.30, 0, 0.05)
        for j in range(16):
            tj = t0 + j * 0.125
            if tj >= 72.5: break
            g = 0.09 if sec == 'build' else 0.11
            add(pluck(arp[j % 8], 0.3, 3500), tj, g, -0.45 if j % 2 else 0.45, 0.3)
            add(pluck(arp[j % 8], 0.3, 2000), tj + 0.375, g * 0.35, 0.45 if j % 2 else -0.45, 0.3)
        for b in range(4):
            tb = t0 + b * 0.5
            if tb >= 72.5: break
            add(kick(), tb, 0.85, 0, 0.02); kick_times.append(tb)
            if sec != 'build' and b in (1, 3): add(clap(), tb, 0.30, 0.05, 0.3)
            add(hat(0.02), tb + 0.25, 0.10, 0.35, 0.05)
            if sec in ('full', 'lift'):
                add(hat(0.012), tb + 0.125, 0.045, -0.35, 0.05); add(hat(0.012), tb + 0.375, 0.045, -0.35, 0.05)
            if sec == 'lift' and b % 2 == 1: add(hat(0.09), tb + 0.25, 0.06, 0.4, 0.1)
        if sec in ('full', 'lift') and k % 2 == 0:
            for dt, m in ((0.0, arp[2] + 12), (0.75, arp[1] + 12), (1.0, arp[0] + 12), (1.5, arp[2] + 12)):
                add(bell(m - 12, 1.2, 0.5), t0 + dt, 0.035, 0.2, 0.5)
        if t0 + 2 in (23, 37, 53, 61):
            for j, tf in enumerate(np.arange(t0 + 1.5, t0 + 2.0, 0.125)):
                add(snare(0.05), tf, 0.10 + 0.05 * j, 0.1, 0.25)

    # final hit at 73 s, then ring out
    add(kick(1.2), 73.0, 0.9, 0, 0.1)
    add(stereo(cymbal(4.0, 1.4), cymbal(4.0, 1.4)), 73.0, 0.16, 0, 0.5)
    add_pad(pad(CHORDS[0][1] + [66], 5.2, 0.05, 2.5, 1800), 73.0, 0.6)
    add(sub_drop(70, 30, 1.8), 73.0, 0.45, 0, 0.05)
    for i, (dt, m) in enumerate(((0.0, 74), (0.25, 78), (0.5, 81), (0.75, 86))):
        add(bell(m, 2.5, 1.0), 73.0 + dt, 0.05, [-0.3, 0.3, -0.1, 0.1][i], 0.6)

    # side-chain pump on the pads
    duck = np.ones(N)
    for kt in kick_times:
        i0 = int(kt * SR); n = min(int(0.45 * SR), N - i0)
        duck[i0:i0 + n] = np.minimum(duck[i0:i0 + n], 1 - 0.55 * np.exp(-tt(n) / 0.13))
    dryL += padL * duck; dryR += padR * duck
    revL += padL * duck * 0.35; revR += padR * duck * 0.35

    # UI sound effects from the scene cue sheet
    for kind, t0, g in sfx:
        if kind == 'whoosh':
            w = whoosh(0.5, 500, 7000); add(stereo(w, w[::-1] * 0.6), t0 - 0.2, 0.16 * g, 0, 0.3)
        elif kind == 'pop': add(blip(520, 1100, 0.09), t0, 0.12 * g, 0.1, 0.25)
        elif kind == 'tick': add(blip(2400, 2600, 0.035), t0, 0.06 * g, 0.2, 0.2)
        elif kind == 'check': add(blip(1100, 1700, 0.07), t0, 0.07 * g, -0.1, 0.25)
        elif kind == 'click': add(ui_click(), t0, 0.35 * g, 0.15, 0.05)
        elif kind == 'key':
            n = int(0.02 * SR); add(filt(noise(n), 'band', (1500, 5000)) * np.exp(-tt(n) / 0.003), t0, 0.08 * g, 0.2, 0.05)
        elif kind == 'success':
            add(bell(81, 1.2, 0.4), t0, 0.06 * g, -0.2, 0.4); add(bell(88, 1.2, 0.4), t0 + 0.09, 0.06 * g, 0.2, 0.4)
        elif kind == 'block': add(thud(), t0, 0.18 * g, 0, 0.1)
        elif kind == 'hit':
            add(stereo(cymbal(2.0, 0.8), cymbal(2.0, 0.8)), t0, 0.08 * g, 0, 0.4)
            add(sub_drop(60, 35, 1.0), t0, 0.25 * g, 0, 0.05)
        elif kind == 'hit2':
            for m in (62, 66, 69, 74): add(pluck(m, 0.4, 5000), t0, 0.06 * g, 0, 0.35)
            add(clap(), t0, 0.2 * g, 0, 0.3)
        elif kind == 'rise': add(riser(1.0, 400, 9000), t0, 0.22 * g, 0, 0.25)

    # reverb + master
    irn = int(2.2 * SR); ti = tt(irn)
    def ir():
        x = noise(irn) * np.exp(-ti / 0.35)
        x = filt(filt(x, 'low', 6000), 'high', 250); x[:int(0.015 * SR)] = 0
        return x / np.sqrt(np.sum(x ** 2))
    L = dryL + fftconvolve(revL, ir())[:N] * 0.7
    R = dryR + fftconvolve(revR, ir())[:N] * 0.7
    L, R = filt(L, 'high', 28), filt(R, 'high', 28)
    pk = max(np.abs(L).max(), np.abs(R).max()); L /= pk; R /= pk
    L = np.tanh(L * 1.3) / np.tanh(1.3); R = np.tanh(R * 1.3) / np.tanh(1.3)
    tfull = tt(N)
    fo = np.clip((dur - 0.05 - tfull) / 2.2, 0, 1) * np.clip(tfull / 0.05, 0, 1)
    L *= fo; R *= fo
    pk = max(np.abs(L).max(), np.abs(R).max()); L *= 0.92 / pk; R *= 0.92 / pk
    wavfile.write(str(path), SR, (np.clip(np.column_stack([L, R]), -1, 1) * 32767).astype(np.int16))
    return path
