"""Rendering primitives: easing, 3D cards, SDF shapes, text, cursor, background, transitions.

All drawing happens on float32 RGB frames (H, W, 3) in 0..1, at 1920x1080.
"""
import math
from functools import lru_cache
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 1920, 1080, 30
FONT_DIR = Path(__file__).resolve().parent.parent / 'fonts'

MINT = np.array([0.26, 0.87, 0.62], np.float32)
MINT_D = np.array([0.12, 0.36, 0.29], np.float32)
WHITE = np.array([0.97, 0.98, 0.98], np.float32)
SUB = np.array([0.62, 0.69, 0.71], np.float32)
INK = np.array([0.06, 0.08, 0.09], np.float32)
RED = np.array([0.95, 0.34, 0.31], np.float32)
PANEL = np.array([0.075, 0.095, 0.105], np.float32)
UI_GREEN = np.array([0.42, 0.77, 0.60], np.float32)


# ---------------------------------------------------------------- easing
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def lin(t, t0, t1): return clamp((t - t0) / (t1 - t0)) if t1 > t0 else float(t >= t1)
def ease_io(x): x = clamp(x); return x * x * (3 - 2 * x)
def ease_io5(x): x = clamp(x); return x ** 3 * (x * (6 * x - 15) + 10)
def ease_out(x, p=3): x = clamp(x); return 1 - (1 - x) ** p
def ease_in(x, p=3): x = clamp(x); return x ** p
def mix(a, b, x): return a + (b - a) * x
def fade(t, t_in, t_out, d_in=0.3, d_out=0.3):
    return clamp(min((t - t_in) / d_in if d_in > 0 else 1, (t_out - t) / d_out if d_out > 0 else 1))
def ease_back(x, s=1.6):
    x = clamp(x) - 1
    return 1 + (s + 1) * x ** 3 + s * x ** 2
def ease_out_expo(x):
    x = clamp(x); return 1 if x >= 1 else 1 - 2 ** (-10 * x)
def ease_in_expo(x):
    x = clamp(x); return 0 if x <= 0 else 2 ** (10 * x - 10)
def ease_io_expo(x):
    x = clamp(x)
    if x in (0, 1): return x
    return 2 ** (20 * x - 10) / 2 if x < 0.5 else (2 - 2 ** (-20 * x + 10)) / 2


# ---------------------------------------------------------------- image plates (screenshots)
class Plate:
    """A screenshot as a premultiplied RGBA image pyramid with rounded corners."""
    def __init__(self, rgb_u8, radius=16):
        im = rgb_u8.astype(np.float32) / 255
        h, w = im.shape[:2]
        a = np.zeros((h, w), np.uint8)
        cv2.rectangle(a, (radius, 0), (w - radius, h), 255, -1)
        cv2.rectangle(a, (0, radius), (w, h - radius), 255, -1)
        for cx, cy in [(radius, radius), (w - radius, radius), (radius, h - radius), (w - radius, h - radius)]:
            cv2.circle(a, (cx, cy), radius, 255, -1, cv2.LINE_AA)
        rgba = np.dstack([im, a.astype(np.float32) / 255])
        rgba[..., :3] *= rgba[..., 3:4]
        self.w, self.h = w, h
        self.levels = [(1.0, rgba)]
        s = 1.0
        while True:                       # half-octave pyramid: never shrink more than ~0.7x in one warp
            s /= 2 ** 0.5
            if min(w, h) * s < 64: break
            self.levels.append((s, cv2.resize(rgba, (max(1, round(w * s)), max(1, round(h * s))), interpolation=cv2.INTER_AREA)))

    def pick(self, zoom):
        """smallest pyramid level that still has at least `zoom` resolution (no upscaling of a reduced level)"""
        best = self.levels[0]
        for s, im in self.levels:
            if zoom <= s * 1.02: best = (s, im)
        return best


def rotmat(rx, ry, rz):
    rx, ry, rz = map(math.radians, (rx, ry, rz))
    Rx = np.array([[1, 0, 0], [0, math.cos(rx), -math.sin(rx)], [0, math.sin(rx), math.cos(rx)]])
    Ry = np.array([[math.cos(ry), 0, math.sin(ry)], [0, 1, 0], [-math.sin(ry), 0, math.cos(ry)]])
    Rz = np.array([[math.cos(rz), -math.sin(rz), 0], [math.sin(rz), math.cos(rz), 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


class Cam:
    """Perspective camera looking at a plate. (cx, cy) plate px shown at screen centre (+ox, oy)."""
    def __init__(self, cx, cy, zoom, rx=0, ry=0, rz=0, ox=0, oy=0, f=1700):
        self.cx, self.cy, self.zoom = cx, cy, zoom
        self.R = rotmat(rx, ry, rz); self.ox, self.oy, self.f = ox, oy, f

    def project(self, pts):
        pts = np.asarray(pts, np.float64).reshape(-1, 2)
        P = np.column_stack([(pts[:, 0] - self.cx) * self.zoom, (pts[:, 1] - self.cy) * self.zoom, np.zeros(len(pts))])
        P = P @ self.R.T
        z = P[:, 2] + self.f
        x = self.f * P[:, 0] / z + W / 2 + self.ox
        y = self.f * P[:, 1] / z + H / 2 + self.oy
        return np.column_stack([x, y]).astype(np.float32)

    def H(self, scale=1.0):
        src = np.float32([[0, 0], [1000, 0], [1000, 1000], [0, 1000]])
        return cv2.getPerspectiveTransform(src, self.project(src / scale))


def render_plate(plate, cam):
    lvl_s, img = plate.pick(cam.zoom)
    return cv2.warpPerspective(img, cam.H(lvl_s), (W, H), flags=cv2.INTER_LINEAR,
                               borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))


def over(dst, src_rgba, opacity=1.0):
    a = src_rgba[..., 3:4] * opacity
    dst *= (1 - a)
    dst += src_rgba[..., :3] * opacity
    return dst


def fast_blur(img, sigma):
    if sigma <= 0.3: return img
    if sigma < 6: return cv2.GaussianBlur(img, (0, 0), sigma)
    k = int(min(8, sigma / 3))
    small = cv2.resize(img, (img.shape[1] // k, img.shape[0] // k), interpolation=cv2.INTER_AREA)
    small = cv2.GaussianBlur(small, (0, 0), sigma / k)
    return cv2.resize(small, (img.shape[1], img.shape[0]), interpolation=cv2.INTER_LINEAR)


# ---------------------------------------------------------------- SDF shapes
def _grid(x0, y0, x1, y1):
    X0, Y0 = max(0, int(math.floor(x0)) - 2), max(0, int(math.floor(y0)) - 2)
    X1, Y1 = min(W, int(math.ceil(x1)) + 2), min(H, int(math.ceil(y1)) + 2)
    if X1 <= X0 or Y1 <= Y0: return None
    ys, xs = np.mgrid[Y0:Y1, X0:X1].astype(np.float32)
    return X0, Y0, X1, Y1, xs + 0.5, ys + 0.5


def rrect_sdf(xs, ys, box, r):
    x0, y0, x1, y1 = box
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; bx, by = (x1 - x0) / 2, (y1 - y0) / 2
    r = min(r, bx, by)
    qx = np.abs(xs - cx) - bx + r; qy = np.abs(ys - cy) - by + r
    return np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0) - r


def rrect_mask(box, r, pad=0):
    m = np.zeros((H, W), np.float32)
    g = _grid(box[0] - pad, box[1] - pad, box[2] + pad, box[3] + pad)
    if g is None: return m
    X0, Y0, X1, Y1, xs, ys = g
    m[Y0:Y1, X0:X1] = np.clip(0.5 - rrect_sdf(xs, ys, box, r), 0, 1)
    return m


def fill_rrect(frame, box, r, color, alpha=1.0, glow=0.0, glow_color=None):
    if alpha <= 0.002: return
    pad = 2 + (40 if glow > 0 else 0)
    g = _grid(box[0] - pad, box[1] - pad, box[2] + pad, box[3] + pad)
    if g is None: return
    X0, Y0, X1, Y1, xs, ys = g
    d = rrect_sdf(xs, ys, box, r)
    a = np.clip(0.5 - d, 0, 1)[..., None] * alpha
    reg = frame[Y0:Y1, X0:X1]
    if glow > 0:
        gl = np.exp(-np.maximum(d, 0) / 14.0)[..., None] * (d > 0)[..., None] * glow * alpha
        reg += gl * (glow_color if glow_color is not None else color)
    reg *= (1 - a); reg += a * np.asarray(color, np.float32)


def stroke_rrect(frame, box, r, color, width=2.0, alpha=1.0, glow=0.0):
    if alpha <= 0.002: return
    pad = 3 + width + (36 if glow > 0 else 0)
    g = _grid(box[0] - pad, box[1] - pad, box[2] + pad, box[3] + pad)
    if g is None: return
    X0, Y0, X1, Y1, xs, ys = g
    d = np.abs(rrect_sdf(xs, ys, box, r))
    a = np.clip(width / 2 + 0.5 - d, 0, 1)[..., None] * alpha
    reg = frame[Y0:Y1, X0:X1]
    if glow > 0: reg += np.exp(-d / 12.0)[..., None] * glow * alpha * np.asarray(color, np.float32)
    reg *= (1 - a); reg += a * np.asarray(color, np.float32)


def fill_circle(frame, cx, cy, rad, color, alpha=1.0):
    fill_rrect(frame, (cx - rad, cy - rad, cx + rad, cy + rad), rad, color, alpha)


def stroke_circle(frame, cx, cy, rad, color, width=2, alpha=1.0, glow=0.0):
    stroke_rrect(frame, (cx - rad, cy - rad, cx + rad, cy + rad), rad, color, width, alpha, glow)


def capsule(frame, p0, p1, width, color, alpha=1.0):
    if alpha <= 0.002: return
    x0, y0 = p0; x1, y1 = p1
    g = _grid(min(x0, x1) - width - 2, min(y0, y1) - width - 2, max(x0, x1) + width + 2, max(y0, y1) + width + 2)
    if g is None: return
    X0, Y0, X1, Y1, xs, ys = g
    dx, dy = x1 - x0, y1 - y0; L2 = dx * dx + dy * dy + 1e-6
    t = np.clip(((xs - x0) * dx + (ys - y0) * dy) / L2, 0, 1)
    d = np.hypot(xs - (x0 + t * dx), ys - (y0 + t * dy))
    a = np.clip(width / 2 + 0.5 - d, 0, 1)[..., None] * alpha
    reg = frame[Y0:Y1, X0:X1]; reg *= (1 - a); reg += a * np.asarray(color, np.float32)


def shadow_rrect(frame, box, r, strength=0.5, blur=26, dy=16):
    x0, y0, x1, y1 = box
    pad = blur * 3
    X0, Y0 = max(0, int(x0 - pad)), max(0, int(y0 - pad + dy))
    X1, Y1 = min(W, int(x1 + pad)), min(H, int(y1 + pad + dy))
    if X1 <= X0 or Y1 <= Y0: return
    ys, xs = np.mgrid[Y0:Y1, X0:X1].astype(np.float32)
    d = rrect_sdf(xs + 0.5, ys + 0.5 - dy, box, r)
    a = np.clip(1 - d / blur, 0, 1) ** 2
    a = np.where(d < 0, 1.0, a)
    frame[Y0:Y1, X0:X1] *= (1 - strength * a[..., None])


# ---------------------------------------------------------------- screenshot cards
def lerp_box(a, b, x): return tuple(mix(p, q, x) for p, q in zip(a, b))


def fit_box(region, cx, cy, width):
    x0, y0, x1, y1 = region; h = width * (y1 - y0) / (x1 - x0)
    return (cx - width / 2, cy - h / 2, cx + width / 2, cy + h / 2)


def screen_box(cam, region):
    q = cam.project([(region[0], region[1]), (region[2], region[1]), (region[2], region[3]), (region[0], region[3])])
    return (q[:, 0].min(), q[:, 1].min(), q[:, 0].max(), q[:, 1].max())


def draw_crop(frame, pl, region, dst, alpha=1.0, radius=14, shadow=0.45, outline=0.0, ocolor=None, bright=1.0):
    """Draw a plate region (plate px) into a flat screen rect with rounded corners."""
    if alpha <= 0.003: return
    x0, y0, x1, y1 = region; dx0, dy0, dx1, dy1 = dst
    if dx1 - dx0 < 2 or dy1 - dy0 < 2: return
    sx = (dx1 - dx0) / (x1 - x0); sy = (dy1 - dy0) / (y1 - y0)
    lvl_s, img = pl.pick(min(sx, sy))
    if shadow > 0: shadow_rrect(frame, dst, radius, shadow * alpha, 28, 18)
    X0, Y0, X1, Y1 = max(0, int(dx0) - 1), max(0, int(dy0) - 1), min(W, int(dx1) + 2), min(H, int(dy1) + 2)
    if X1 <= X0 or Y1 <= Y0: return
    M = np.float32([[sx / lvl_s, 0, dx0 - x0 * sx - X0], [0, sy / lvl_s, dy0 - y0 * sy - Y0]])
    patch = cv2.warpAffine(img, M, (X1 - X0, Y1 - Y0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    ys, xs = np.mgrid[Y0:Y1, X0:X1].astype(np.float32)
    m = np.clip(0.5 - rrect_sdf(xs + 0.5, ys + 0.5, dst, radius), 0, 1)[..., None] * alpha
    rgb = patch[..., :3] / np.maximum(patch[..., 3:4], 1e-3) * bright
    reg = frame[Y0:Y1, X0:X1]; reg *= (1 - m); reg += rgb * m
    if outline > 0:
        stroke_rrect(frame, dst, radius, ocolor if ocolor is not None else MINT, 2.5, alpha * outline, glow=0.5)


def card(frame, pl, cam, bright=1.0, dim=0.0, spot=None, spot_r=12, shadow=0.55, alpha=1.0, hole=False):
    """Tilted screenshot card with a soft shadow. dim darkens it; hole keeps `spot` (plate px) bright."""
    lay = render_plate(pl, cam)
    if alpha < 1: lay *= alpha
    a = lay[..., 3]
    if shadow > 0:
        sh = np.roll(fast_blur(a, 30), 22, axis=0)
        frame *= (1 - shadow * sh[..., None])
    if bright != 1.0: lay[..., :3] *= bright
    if dim > 0:
        k = np.full((H, W), 1 - dim, np.float32)
        if spot is not None and hole:
            k = 1 - dim * (1 - rrect_mask(screen_box(cam, spot), spot_r))
        lay[..., :3] *= k[..., None]
    over(frame, lay)
    return lay


# ---------------------------------------------------------------- text
@lru_cache(maxsize=64)
def font(name, size): return ImageFont.truetype(str(FONT_DIR / f'{name}.ttf'), size)


@lru_cache(maxsize=1024)
def text_img(s, fname, size, tracking=0):
    f = font(fname, size)
    widths = [f.getlength(ch) for ch in s]
    total = sum(widths) + tracking * (len(s) - 1)
    asc, desc = f.getmetrics()
    pad = int(size * 0.6)
    im = Image.new('L', (int(total) + pad * 2, asc + desc + pad * 2), 0)
    d = ImageDraw.Draw(im)
    x = pad
    for ch, w in zip(s, widths):
        d.text((x, pad), ch, font=f, fill=255)
        x += w + tracking
    return np.asarray(im, np.float32) / 255, pad, asc


def text_width(s, fname, size, tracking=0):
    f = font(fname, int(size)); return sum(f.getlength(c) for c in s) + tracking * (len(s) - 1)


def text(frame, s, fname, size, x, y, color=WHITE, alpha=1.0, align='left', tracking=0, rise=0.0, clip=True):
    """Draw text vertically centred on y. rise (0..1) = remaining slide-up behind a mask."""
    if alpha <= 0.003 or not s: return 0
    a, pad, asc = text_img(s, fname, int(size), int(round(tracking)))
    h, w = a.shape
    tw = w - 2 * pad
    if align == 'center': x0 = x - tw / 2 - pad
    elif align == 'right': x0 = x - tw - pad
    else: x0 = x - pad
    y0 = y - pad - asc * 0.62
    if rise > 0:
        off = int(round(rise * asc * 1.15))
        if clip:
            sh = np.zeros_like(a)
            if off < h: sh[off:] = a[:h - off]
            top, bot = int(pad * 0.5), int(pad + asc * 1.28)
            sh[:top] = 0; sh[bot:] = 0
            a = sh
        else:
            y0 += off
    x0, y0 = int(round(x0)), int(round(y0))
    sx0, sy0 = max(0, -x0), max(0, -y0); dx0, dy0 = max(0, x0), max(0, y0)
    dx1, dy1 = min(W, x0 + w), min(H, y0 + h)
    if dx1 <= dx0 or dy1 <= dy0: return tw
    sub = a[sy0:sy0 + dy1 - dy0, sx0:sx0 + dx1 - dx0][..., None] * alpha
    reg = frame[dy0:dy1, dx0:dx1]; reg *= (1 - sub); reg += sub * np.asarray(color, np.float32)
    return tw


def words_in(frame, s, fname, size, x, y, t, t0, t_out=None, color=WHITE, align='left', tracking=0, stagger=0.07, dur=0.55):
    """Word-by-word masked slide-up reveal, and a quick staggered exit at t_out."""
    wordsl = s.split(' ')
    f = font(fname, int(size))
    space = f.getlength(' ') + tracking
    widths = [f.getlength(wd) + tracking * max(0, len(wd) - 1) for wd in wordsl]
    total = sum(widths) + space * (len(wordsl) - 1)
    cx = x - total / 2 if align == 'center' else (x - total if align == 'right' else x)
    for i, (wd, ww) in enumerate(zip(wordsl, widths)):
        p = ease_out_expo(lin(t, t0 + i * stagger, t0 + i * stagger + dur))
        a = 1.0 if p > 0 else 0.0
        if t_out is not None and t > t_out:
            q = ease_in(lin(t, t_out + i * 0.03, t_out + i * 0.03 + 0.35), 2)
            if q > 0:
                text(frame, wd, fname, size, cx, y - q * size * 0.5, color, a * (1 - q), 'left', tracking)
                cx += ww + space; continue
        if a > 0: text(frame, wd, fname, size, cx, y, color, a, 'left', tracking, rise=1 - p)
        cx += ww + space
    return total


def chapter(frame, t, t0, t_out, num, label, x=120, y=250, color=MINT):
    p = ease_out_expo(lin(t, t0, t0 + 0.6)); q = ease_in(lin(t, t_out, t_out + 0.35), 2) if t_out else 0
    a = 1 - q
    if p <= 0 or a <= 0: return
    capsule(frame, (x, y), (x + 36 * p, y), 3, color, a)
    text(frame, num, 'inter700', 20, x + 50, y + 1, color, a * p, tracking=2)
    text(frame, label, 'inter600', 20, x + 86, y + 1, SUB, a * p, tracking=6, rise=1 - p)


def label_pill(frame, s, x, y, t, t0, t_out=None, anchor=None, align='left', size=24, dark=True):
    """Callout pill; (x, y) is the pill's left-middle. anchor draws a pointer line + dot."""
    p = ease_back(lin(t, t0, t0 + 0.45)); q = ease_in(lin(t, t_out, t_out + 0.3), 2) if t_out else 0
    a = clamp(lin(t, t0, t0 + 0.15)) * (1 - q)
    if a <= 0: return
    tw = text_width(s, 'inter600', size, 0)
    ph = size * 2.0; pw = tw + size * 2.6
    if align == 'right': x = x - pw
    elif align == 'center': x = x - pw / 2
    sc = mix(0.6, 1.0, p)
    cx, cy = x + pw / 2, y
    box = (cx - pw / 2 * sc, cy - ph / 2 * sc, cx + pw / 2 * sc, cy + ph / 2 * sc)
    if anchor is not None:
        lp = ease_out_expo(lin(t, t0 + 0.1, t0 + 0.5))
        ax, ay = anchor
        sx = box[0] if ax < box[0] else (box[2] if ax > box[2] else cx)
        ex, ey = mix(sx, ax, lp), mix(cy, ay, lp)
        capsule(frame, (sx, cy), (ex, ey), 2.2, MINT, a)
        fill_circle(frame, ex, ey, 6 * lp, MINT, a)
        stroke_circle(frame, ax, ay, 13 * lp, MINT, 2, a * 0.6 * lp)
    shadow_rrect(frame, box, ph / 2, 0.35 * a, 20, 10)
    fill_rrect(frame, box, ph / 2 * sc, PANEL if dark else WHITE, a * 0.96)
    stroke_rrect(frame, box, ph / 2 * sc, MINT, 1.5, a * 0.8)
    fill_circle(frame, box[0] + size * 0.95 * sc, cy, size * 0.22 * sc, MINT, a)
    if sc > 0.85:
        text(frame, s, 'inter600', size, box[0] + size * 1.6, cy + 1, WHITE if dark else INK, a * clamp((sc - 0.85) / 0.15))


# ---------------------------------------------------------------- cursor
def _make_cursor(scale=2.4, ss=4):
    pts = [(0, 0), (0, 18), (4.3, 14), (7.3, 20.6), (10.2, 19.4), (7.3, 13), (13, 13)]
    S = scale * ss; pad = 6 * ss
    w = int(15 * S + pad * 2); h = int(23 * S + pad * 2)
    im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    P = [(pad + x * S, pad + y * S) for x, y in pts]
    d.polygon(P, fill=(0, 0, 0, 255))
    cx = sum(p[0] for p in P) / len(P); cy = sum(p[1] for p in P) / len(P)
    Pi = [(cx + (x - cx) * 0.80, cy + (y - cy) * 0.84) for x, y in P]
    Pi[0] = (P[0][0] + 1.6 * S, P[0][1] + 3.0 * S)
    d.polygon(Pi, fill=(255, 255, 255, 255))
    im = im.resize((w // ss, h // ss), Image.LANCZOS)
    a = np.asarray(im, np.float32) / 255
    return a, cv2.GaussianBlur(a[..., 3], (0, 0), 3), pad / ss
CURSOR = _make_cursor()


def draw_cursor(frame, x, y, alpha=1.0, press=0.0):
    a, sh, pad = CURSOR
    s = 1 - 0.12 * press
    rgba = a if s == 1 else cv2.resize(a, (int(a.shape[1] * s), int(a.shape[0] * s)), interpolation=cv2.INTER_AREA)
    shd = sh if s == 1 else cv2.resize(sh, (rgba.shape[1], rgba.shape[0]))
    x0 = int(x - pad * s); y0 = int(y - pad * s)
    h, w = rgba.shape[:2]
    if x0 < 0 or y0 < 0 or x0 + w + 8 >= W or y0 + h + 8 >= H: return frame
    reg = frame[y0 + 5:y0 + 5 + h, x0 + 4:x0 + 4 + w]
    reg *= (1 - 0.45 * alpha * shd[..., None])
    reg = frame[y0:y0 + h, x0:x0 + w]
    al = rgba[..., 3:4] * alpha
    reg *= (1 - al); reg += rgba[..., :3] * al
    return frame


# ---------------------------------------------------------------- background
_yy, _xx = np.mgrid[0:H, 0:W].astype(np.float32)


def _make_bg():
    base = np.zeros((H, W, 3), np.float32)
    top = np.array([0.043, 0.055, 0.062]); bot = np.array([0.028, 0.036, 0.040])
    base[:] = top * (1 - _yy / H)[..., None] + bot * (_yy / H)[..., None]
    for cx, cy, r, col, a in ((0.22, 0.25, 900, (0.06, 0.25, 0.20), 0.55), (0.85, 0.85, 1000, (0.05, 0.14, 0.18), 0.5)):
        d = np.hypot(_xx - cx * W, _yy - cy * H) / r
        base += np.exp(-d * d * 2.2)[..., None] * np.array(col) * a
    step = 36
    dots = np.clip(1.6 - np.hypot((_xx % step) - step / 2, (_yy % step) - step / 2), 0, 1)
    vign = np.clip(1.0 - 0.55 * (np.hypot((_xx - W / 2) / (W / 2), (_yy - H / 2) / (H / 2)) ** 2), 0.3, 1)
    base += dots[..., None] * 0.035 * vign[..., None]
    return base.astype(np.float32), vign.astype(np.float32)
BG, VIGN = _make_bg()

SHAPES = [('pill', 0.10, 0.18, 260, 64, 0.8, 0.0), ('circle', 0.88, 0.22, 90, 90, 0.6, 1.3), ('rect', 0.80, 0.78, 300, 170, 0.5, 2.1),
          ('pill', 0.20, 0.84, 180, 50, 0.7, 3.3), ('circle', 0.52, 0.10, 44, 44, 0.9, 4.0), ('pill', 0.60, 0.92, 220, 56, 0.6, 5.2)]


def background(t, shapes=0.6, drift=1.0):
    f = BG.copy()
    if shapes > 0:
        for kind, x, y, w, h, sp, ph in SHAPES:
            cx = x * W + 30 * math.sin(t * 0.25 * sp + ph) * drift
            cy = y * H + 22 * math.cos(t * 0.21 * sp + ph) * drift - t * 4 * sp
            cy = (cy + 100) % (H + 200) - 100
            r = h / 2 if kind != 'rect' else 18
            stroke_rrect(f, (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), r, MINT, 1.5, 0.10 * shapes)
    return f


def finish(f, t, flash=0.0):
    f *= VIGN[..., None] * 0.2 + 0.8
    if flash > 0: f += flash
    r = np.random.default_rng(int(t * 1000) + 5)
    n = cv2.resize(r.standard_normal((H // 2, W // 2)).astype(np.float32), (W, H))
    f += n[..., None] * 0.006
    return np.clip(f * 255 + 0.5, 0, 255).astype(np.uint8)


# ---------------------------------------------------------------- transitions
def shape_reveal(fa, fb, t01, box0, box1, r0, r1, rim=True, fill=None):
    """Reveal fb inside a rounded shape growing from box0 to box1, with a mint rim and optional colour fill."""
    x = ease_io_expo(t01) if t01 < 1 else 1
    box = lerp_box(box0, box1, x)
    r = mix(r0, r1, x)
    m = rrect_mask(box, r)[..., None]
    inner = fb
    if fill is not None:
        k = clamp(1 - lin(t01, 0.35, 0.85))
        inner = fb * (1 - k) + np.asarray(fill, np.float32) * k
    out = fa * (1 - m) + inner * m
    if rim and 0 < t01 < 1:
        stroke_rrect(out, box, r, MINT, 4, (1 - x) ** 0.5, glow=0.8)
    return out


def full_box(cx, cy, scale=1.3):
    rad = math.hypot(max(cx, W - cx), max(cy, H - cy)) * scale
    return (cx - rad, cy - rad, cx + rad, cy + rad)
