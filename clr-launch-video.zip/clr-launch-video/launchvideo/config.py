"""Loads config/screens.json + config/storyboard.json and the screenshots they point to."""
import json
from pathlib import Path

import cv2
import numpy as np

from .engine import Plate

ROOT = Path(__file__).resolve().parent.parent


def imread_rgb(path):
    """cv2.imread that also works with non-ASCII Windows paths; drops alpha."""
    data = np.fromfile(str(path), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f'Could not read image: {path}')
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


class Screens:
    def __init__(self, screens_json=None, root=None):
        self.path = Path(screens_json or ROOT / 'config' / 'screens.json')
        self.root = Path(root or ROOT)
        self.cfg = json.loads(self.path.read_text(encoding='utf-8'))['screens']
        self._plates = {}

    def keys(self):
        return list(self.cfg)

    def file(self, key):
        return self.root / self.cfg[key]['file']

    def missing(self):
        return [k for k in self.cfg if not self.file(k).exists()]

    def image(self, key):
        f = self.file(key)
        if not f.exists():
            raise FileNotFoundError(f'Screenshot for "{key}" not found at {f}\n  Capture: {self.cfg[key].get("capture", "")}')
        return imread_rgb(f)

    def plate(self, key):
        if key not in self._plates:
            self._plates[key] = Plate(self.image(key), radius=16)
        return self._plates[key]

    def r(self, key, name):
        """Named region in plate pixels (x0, y0, x1, y1)."""
        pl = self.plate(key)
        try:
            x0, y0, x1, y1 = self.cfg[key]['regions'][name]
        except KeyError:
            raise KeyError(f'Region "{name}" missing for screen "{key}" in {self.path}')
        return (x0 * pl.w, y0 * pl.h, x1 * pl.w, y1 * pl.h)

    def p(self, key, name):
        x0, y0, x1, y1 = self.r(key, name)
        return ((x0 + x1) / 2, (y0 + y1) / 2)


def load_story(path=None):
    return json.loads(Path(path or ROOT / 'config' / 'storyboard.json').read_text(encoding='utf-8'))
