"""The 78-second storyboard. Timings are absolute seconds; positions come from named regions in screens.json;
all words come from storyboard.json. Call init() once per process before render()."""
import math

import cv2
import numpy as np

from .engine import *

DUR = 78.0
S = None          # Screens
T = None          # storyboard text
SFX = []          # (kind, time, gain) cue sheet shared with the music generator
_cache = {}


def cue(kind, t, g=1.0): SFX.append((kind, t, g))


# ---------------------------------------------------------------- helpers
def ccam(key, cx_s, cy_s, width, rx=0, ry=0, rz=0, dx=0, dy=0, zmul=1.0):
    pl = S.plate(key)
    return Cam(pl.w / 2, pl.h / 2, width / pl.w * zmul, rx, ry, rz, cx_s - W / 2 + dx, cy_s - H / 2 + dy)


def fsample(f, box):
    x0, y0, x1, y1 = [int(v) for v in box]
    x0, x1 = max(0, x0), min(W, x1); y0, y1 = max(0, y0), min(H, y1)
    if x1 <= x0 or y1 <= y0: return np.array([0.9, 0.92, 0.92], np.float32)
    return np.median(f[y0:y1, x0:x1].reshape(-1, 3), axis=0)


def enter(t, t0, dur=0.9): return ease_out_expo(lin(t, t0, t0 + dur))


def liftout(frame, pl, cam, region, target, t, t0, t1, radius=12, outline=1.0):
    p = ease_back(lin(t, t0, t0 + 0.55), 1.1)
    q = ease_io(lin(t, t1 - 0.4, t1))
    x = p * (1 - q)
    if x <= 0.001: return None, 0
    box = lerp_box(screen_box(cam, region), target, x)
    draw_crop(frame, pl, region, box, 1.0, radius, 0.55 * min(1, x), outline * min(1, x))
    return box, x


def lift_amt(t, t0, t1): return ease_io(lin(t, t0, t0 + 0.4)) * (1 - ease_io(lin(t, t1 - 0.4, t1)))


def inside(bx, reg, u, v):
    """map plate point (u, v) inside region `reg` to the lifted-out screen box `bx`"""
    return (mix(bx[0], bx[2], (u - reg[0]) / (reg[2] - reg[0])), mix(bx[1], bx[3], (v - reg[1]) / (reg[3] - reg[1])))


def text_block(f, t, t0, t_out, side, key, size=58):
    sc = T[key]; x = 120 if side == 'left' else 1290
    chapter(f, t, t0, t_out, sc['chapter'][0], sc['chapter'][1], x, 330)
    lines = sc['headline']
    for i, ln in enumerate(lines):
        col = MINT if i == len(lines) - 1 else WHITE
        words_in(f, ln, 'inter800', size, x, 410 + i * 70, t, t0 + 0.15 + i * 0.12, t_out, col)
    for i, ln in enumerate(sc['sub']):
        words_in(f, ln, 'inter400', 26, x, 410 + len(lines) * 70 + 20 + i * 38, t, t0 + 0.45 + i * 0.08, t_out, SUB, stagger=0.03)


def L(key, name): return T[key]['labels'][name]


def click_ring(f, x, y, t, tc):
    k = lin(t, tc, tc + 0.45)
    if 0 < k < 1: stroke_circle(f, x, y, mix(8, 46, ease_out(k)), MINT, 3, (1 - k), glow=0.6)


def cursor_path(t, pts):
    if t <= pts[0][0]: return pts[0][1]
    for (t0, p0), (t1, p1) in zip(pts, pts[1:]):
        if t <= t1:
            x = ease_io5(lin(t, t0, t1)); return (mix(p0[0], p1[0], x), mix(p0[1], p1[1], x))
    return pts[-1][1]


def cur(f, t, ta, tb, pts, press_t=None):
    a = fade(t, ta, tb, 0.25, 0.2)
    if a <= 0: return
    x, y = cursor_path(t, pts)
    draw_cursor(f, x, y, a, 1.0 if press_t is not None and press_t <= t < press_t + 0.12 else 0.0)


# ================================================================ S0 INTRO (0 - 5)
LOGO_BOX = (W / 2 - 430, H / 2 - 130, W / 2 + 430, H / 2 + 130)


def logo(f, t, t0, box, alpha=1.0, sub=True):
    it = T['intro']
    cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
    sc = (box[2] - box[0]) / 860
    a_, b_ = it['product_serif'], it['product_light']
    wc = text_width(a_, 'playfair900', 150 * sc); wp = text_width(b_, 'inter200', 132 * sc); gap = 16 * sc
    x0 = cx - (wc + gap + wp) / 2
    p = ease_out_expo(lin(t, t0, t0 + 0.7))
    if p > 0:
        text(f, a_, 'playfair900', 150 * sc, x0, cy - 22 * sc, WHITE, alpha, rise=1 - p)
        p2 = ease_out_expo(lin(t, t0 + 0.12, t0 + 0.82))
        text(f, b_, 'inter200', 132 * sc, x0 + wc + gap, cy - 16 * sc, WHITE, alpha, rise=1 - p2)
    if sub:
        p3 = ease_out_expo(lin(t, t0 + 0.45, t0 + 1.2))
        if p3 > 0:
            text(f, it['product_subtitle'], 'inter600', 21 * sc, cx, cy + 78 * sc, SUB, alpha * p3, 'center', tracking=mix(20, 9, p3) * sc)


def s_intro(t):
    f = background(t, 0.6 * ease_io(lin(t, 0, 2)))
    exit_k = ease_in_expo(lin(t, 4.35, 4.95))
    p0 = ease_back(lin(t, 0.35, 0.7)); p1 = ease_io_expo(lin(t, 1.0, 1.8)); p2 = ease_io_expo(lin(t, 1.8, 2.4))
    cx, cy = W / 2, H / 2
    w = mix(mix(0, 26, p0), 520, p1); h = mix(mix(0, 26, p0), 90, p1)
    box = lerp_box((cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2), LOGO_BOX, p2)
    r = mix(h / 2, 30, p2)
    col = MINT * (1 - p2) + PANEL * p2
    if exit_k > 0:
        bw, bh = (box[2] - box[0]) * mix(1, 0.6, exit_k), (box[3] - box[1]) * mix(1, 0.6, exit_k)
        cy2 = cy - exit_k * 420
        box = (cx - bw / 2, cy2 - bh / 2, cx + bw / 2, cy2 + bh / 2)
    a = 1 - exit_k
    if p0 > 0 and a > 0:
        shadow_rrect(f, box, r, 0.5 * p2 * a, 40, 24)
        fill_rrect(f, box, r, col, a, glow=0.35 * (1 - p2), glow_color=MINT)
        if p2 > 0: stroke_rrect(f, box, r, MINT, 1.6, 0.55 * p2 * a)
        if t >= 2.2: logo(f, t, 2.2, box, a)
    words_in(f, T['intro']['kicker'], 'inter400', 28, W / 2, 330, t, 1.35, 4.2, SUB, 'center', tracking=6)
    words_in(f, T['intro']['tagline'], 'inter400', 32, W / 2, 780, t, 3.05, 4.25, WHITE, 'center', stagger=0.05)
    return f


# ================================================================ S1 DEPARTMENTS (5 - 11)
PILL_H = 66


def dept_boxes():
    names = T['departments']['names']; half = (len(names) + 1) // 2
    fs = 26; boxes = []
    for ri, row in enumerate([names[:half], names[half:]]):
        ws = [text_width(d, 'inter600', fs) + 96 for d in row]
        tot = sum(ws) + 22 * (len(row) - 1); x = W / 2 - tot / 2
        y = 560 + ri * (PILL_H + 22)
        for d, w in zip(row, ws):
            boxes.append((x, y - PILL_H / 2, x + w, y + PILL_H / 2)); x += w + 22
    return boxes


def s_depts(t):
    f = background(t)
    D = T['departments']; names = D['names']; N = len(names); DBOX = _cache['dbox']
    words_in(f, D['title'], 'inter800', 66, W / 2, 330, t, 5.05, 10.1, WHITE, 'center')
    words_in(f, D['title_2'], 'inter800', 66, W / 2, 410, t, 5.45, 10.1, MINT, 'center')
    for i, (d, b) in enumerate(zip(names, DBOX)):
        p = ease_back(lin(t, 6.0 + 0.25 * i, 6.45 + 0.25 * i), 1.8)
        if p <= 0: continue
        last = i == N - 1
        q = ease_in(lin(t, 9.9 + 0.03 * i, 10.2 + 0.03 * i), 2) if not last else 0
        cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
        s = p * (1 - q)
        if s <= 0.01: continue
        bb = (cx - (b[2] - b[0]) / 2 * s, cy - PILL_H / 2 * s, cx + (b[2] - b[0]) / 2 * s, cy + PILL_H / 2 * s)
        chk = ease_back(lin(t, 8.0 + 0.2 * i, 8.35 + 0.2 * i), 2.0)
        fill_rrect(f, bb, PILL_H / 2, UI_GREEN if last else np.array([0.90, 0.93, 0.93], np.float32), 1 - q, glow=0.25 * chk, glow_color=MINT)
        if s > 0.8:
            text(f, d, 'inter600', 26, cx + 16, cy + 1, INK, clamp((s - 0.8) / 0.2) * (1 - q), 'center')
            if chk > 0:
                fill_circle(f, bb[0] + 34, cy, 13 * chk, MINT_D if not last else INK, 1 - q)
                capsule(f, (bb[0] + 28, cy + 1), (bb[0] + 33, cy + 6), 3, WHITE, (1 - q) * clamp(chk))
                capsule(f, (bb[0] + 33, cy + 6), (bb[0] + 41, cy - 5), 3, WHITE, (1 - q) * clamp(chk))
            else:
                stroke_circle(f, bb[0] + 34, cy, 12, INK, 2, 0.35 * (1 - q))
    n = sum(1 for i in range(N) if t >= 8.0 + 0.2 * i)
    a = fade(t, 7.85, 10.0, 0.3, 0.25)
    text(f, f'{n}/{N}', 'inter800', 44, W / 2 - 8, 780, MINT, a, 'right')
    text(f, D['counter_label'], 'inter600', 22, W / 2 + 8, 782, SUB, a, 'left', tracking=6)
    return f


# ================================================================ S2 TASK QUEUE 10.2 - 18.8
def cam_tasks(t):
    e = enter(t, 10.5, 1.1)
    return ccam('tasks', 1250, 560, 1120, rx=mix(14, 3, e), ry=mix(28, 8, e), rz=mix(-4, 0, e),
                dy=(1 - e) * 240, zmul=mix(1.0, 1.05, lin(t, 11, 18.8)))


def s_tasks(t):
    f = background(t)
    pl = S.plate('tasks'); cam = cam_tasks(t)
    la = lift_amt(t, 12.4, 14.3); lb = lift_amt(t, 14.45, 16.4)
    rA = S.r('tasks', 'status_filters'); rB = S.r('tasks', 'signoff_columns')
    card(f, pl, cam, dim=0.55 * max(la, lb), spot=rA if t < 14.37 else rB, alpha=enter(t, 10.5, 0.5))
    text_block(f, t, 11.0, 18.1, 'left', 'tasks')
    bx, _ = liftout(f, pl, cam, rA, fit_box(rA, 1260, 250, 760), t, 12.4, 14.3)
    if bx: label_pill(f, L('tasks', 'status_filters'), bx[0] + 10, bx[3] + 52, t, 12.75, 13.9)
    bx, _ = liftout(f, pl, cam, rB, fit_box(rB, 1540, 560, 380), t, 14.45, 16.4)
    if bx: label_pill(f, L('tasks', 'signoff_columns'), bx[0] - 40, bx[3] - 40, t, 14.8, 16.0,
                      anchor=(bx[0], (bx[1] + bx[3]) / 2), align='right')
    hp = cam.project([S.p('tasks', 'history_icon')])[0]
    hov = lift_amt(t, 17.4, 18.6)
    if hov > 0: stroke_circle(f, hp[0], hp[1], 16, MINT, 2.5, hov, glow=0.7)
    cur(f, t, 16.4, 18.8, [(16.4, (1700, 1000)), (17.4, (hp[0] + 2, hp[1] + 2))], 18.0)
    click_ring(f, hp[0], hp[1], t, 18.0)
    return f


# ================================================================ S3 REVIEW HISTORY 18.2 - 23.6
def cam_hist(t):
    e = enter(t, 18.3, 1.0)
    return ccam('history', 1250, 560, 1000, rx=4 * (1 - e), ry=mix(16, 6, e), dy=(1 - e) * 60, zmul=mix(0.92, 1.0, e))


def go_box():
    return fit_box(S.r('tasks', 'go_button'), W / 2, H / 2, 200)


def s_hist(t):
    f = background(t)
    pl = S.plate('history'); cam = cam_hist(t)
    ex = ease_in_expo(lin(t, 22.05, 22.5))
    rows = [k for k in S.cfg['history']['regions'] if k.startswith('row_')]
    if ex < 1:
        cam.ox -= ex * 900
        card(f, pl, cam, alpha=1 - ex)
        for i, rk in enumerate(sorted(rows, key=lambda s: int(s.split('_')[1]))):
            k = lin(t, 19.8 + 0.3 * i, 20.25 + 0.3 * i)
            if k <= 0: continue
            sb = screen_box(cam, S.r('history', rk))
            if k < 1: stroke_rrect(f, sb, 12, MINT, 2.5, math.sin(math.pi * k), glow=0.8)
            c = ease_back(clamp(k * 2))
            cx, cy = sb[2] + 42, (sb[1] + sb[3]) / 2
            fill_circle(f, cx, cy, 15 * c, MINT, 1 - ex)
            capsule(f, (cx - 6, cy + 1), (cx - 1, cy + 6), 3, INK, (1 - ex) * clamp(c))
            capsule(f, (cx - 1, cy + 6), (cx + 7, cy - 5), 3, INK, (1 - ex) * clamp(c))
        sbx = screen_box(cam, (0, 0, pl.w, pl.h))
        label_pill(f, L('history', 'summary'), sbx[0] + 40, sbx[3] + 58, t, 21.5, 22.1)
    text_block(f, t, 18.6, 22.2, 'left', 'history')
    gp = ease_back(lin(t, 22.5, 22.9), 1.6)
    if gp > 0:            # the Go button from the task list becomes the next transition
        reg = S.r('tasks', 'go_button')
        gb = fit_box(reg, W / 2, H / 2, 200 * gp)
        draw_crop(f, S.plate('tasks'), reg, gb, 1.0, (gb[3] - gb[1]) / 2, 0.5, 0.6)
        cur(f, t, 22.5, 23.6, [(22.5, (W / 2 + 180, H / 2 + 160)), (22.85, (W / 2 + 10, H / 2 + 6))], 22.95)
        click_ring(f, W / 2, H / 2, t, 22.95)
    return f


# ================================================================ S4 CL REVIEW 23.0 - 31.3
def cam_review(t):
    e = enter(t, 23.2, 1.0)
    return ccam('review', 690, 560, 1120, rx=mix(-6, 3, e), ry=mix(-22, -8, e), dy=(1 - e) * 120,
                zmul=mix(1.25, 1.0, e) * mix(1, 1.04, lin(t, 24, 31)))


def s_review(t):
    f = background(t)
    pl = S.plate('review'); cam = cam_review(t)
    la, lb, lc = lift_amt(t, 24.4, 26.2), lift_amt(t, 26.35, 28.3), lift_amt(t, 28.45, 30.2)
    rA, rB, rC = S.r('review', 'context_bar'), S.r('review', 'baseline_columns'), S.r('review', 'filter_chips')
    card(f, pl, cam, dim=0.55 * max(la, lb, lc), spot=rA if t < 26.3 else (rB if t < 28.4 else rC))
    text_block(f, t, 23.5, 30.3, 'right', 'review', size=56)
    bx, _ = liftout(f, pl, cam, rA, fit_box(rA, 690, 200, 1180), t, 24.4, 26.2)
    if bx: label_pill(f, L('review', 'context_bar'), bx[0] + 20, bx[3] + 50, t, 24.75, 25.8)
    bx, x = liftout(f, pl, cam, rB, fit_box(rB, 700, 575, 360), t, 26.35, 28.3)
    if bx:
        label_pill(f, L('review', 'baseline_columns'), 1290, 760, t, 26.7, 27.9, anchor=(bx[2], (bx[1] + bx[3]) / 2))
        px, py = inside(bx, rB, *S.p('review', 'no_flag'))
        k = (math.sin((t - 26.8) * 7) * 0.5 + 0.5) * lin(t, 26.8, 27.1) * x
        stroke_rrect(f, (px - 30, py - 18, px + 30, py + 18), 18, RED, 2.5, k, glow=0.6)
    bx, x = liftout(f, pl, cam, rC, fit_box(rC, 690, 170, 1150), t, 28.45, 30.2)
    if bx:
        label_pill(f, L('review', 'filter_chips'), bx[0] + 20, bx[3] + 50, t, 28.7, 29.8)
        chips = sorted([k for k in S.cfg['review']['regions'] if k.startswith('chip_')], key=lambda s: int(s.split('_')[1]))
        if t >= 28.6 and chips:
            i = int(clamp((t - 28.6) / 0.18, 0, len(chips) - 0.001))
            c = S.r('review', chips[i])
            px0 = inside(bx, rC, c[0], c[1])[0]; px1 = inside(bx, rC, c[2], c[1])[0]
            h = bx[3] - bx[1]
            stroke_rrect(f, (px0, bx[1] + h * 0.12, px1, bx[3] - h * 0.12), h * 0.38, MINT, 2.5, x, glow=0.8)
    cp = cam.project([S.p('review', 'chat_icon')])[0]
    cur(f, t, 29.7, 31.3, [(29.7, (1100, 900)), (30.4, (cp[0] + 2, cp[1] + 2))], 30.6)
    hov = lift_amt(t, 30.3, 31.3)
    if hov > 0: stroke_circle(f, cp[0], cp[1], 18, MINT, 2.5, hov, glow=0.7)
    click_ring(f, cp[0], cp[1], t, 30.6)
    return f


# ================================================================ S5 COMMENT THREAD 30.7 - 37.6
def cam_thread(t):
    e = enter(t, 30.8, 1.0)
    return ccam('thread', 1250, 575, 1060, rx=mix(8, 2, e), ry=mix(20, 7, e), zmul=mix(0.9, 1.0, e))


def s_thread(t):
    f = background(t)
    pl = S.plate('thread'); cam = cam_thread(t)
    la, lb = lift_amt(t, 33.3, 35.0), lift_amt(t, 35.2, 36.9)
    rA, rB = S.r('thread', 'dept_tabs'), S.r('thread', 'bottom_bar')
    card(f, pl, cam, dim=0.55 * max(la, lb), spot=rA if t < 35.1 else rB)
    for i in range(3):                      # messages appear one by one
        k = ease_out_expo(lin(t, 31.7 + 0.5 * i, 32.2 + 0.5 * i))
        if k < 1:
            sb = screen_box(cam, S.r('thread', f'message_{i + 1}'))
            sb = (mix(sb[0], sb[2], k), sb[1], sb[2] + 4, sb[3])
            fill_rrect(f, sb, 4, fsample(f, (sb[2] + 12, sb[1], sb[2] + 70, sb[3])), 1.0)
    text_block(f, t, 31.1, 36.9, 'left', 'thread')
    bx, x = liftout(f, pl, cam, rA, fit_box(rA, 1250, 190, 1180), t, 33.3, 35.0)
    if bx:
        tabs = sorted([k for k in S.cfg['thread']['regions'] if k.startswith('tab_')], key=lambda s: int(s.split('_')[1]))
        if t >= 33.7 and tabs:
            i = int(clamp((t - 33.7) / 0.16, 0, len(tabs) - 0.001))
            c = S.r('thread', tabs[i])
            px0 = inside(bx, rA, c[0], c[1])[0]; px1 = inside(bx, rA, c[2], c[1])[0]
            stroke_rrect(f, (px0, bx[1] + 3, px1, bx[3] - 3), 8, MINT, 2.5, x, glow=0.8)
        label_pill(f, L('thread', 'dept_tabs'), bx[0] + 20, bx[3] + 50, t, 33.6, 34.7)
    bx, x = liftout(f, pl, cam, rB, fit_box(rB, 1250, 930, 1180), t, 35.2, 36.9)
    if bx: label_pill(f, L('thread', 'bottom_bar'), bx[0] + 20, bx[1] - 50, t, 35.5, 36.6)
    return f


# ================================================================ S6 CROSS-AIRCRAFT REUSE 37.0 - 43.4
def xm_box(t):
    reg = S.r('reuse', 'dialog')
    p = ease_back(lin(t, 37.4, 38.0), 1.3)
    tgt = fit_box(reg, 1260, 560, 1000)
    c = ((tgt[0] + tgt[2]) / 2, (tgt[1] + tgt[3]) / 2)
    s = mix(0.7, 1.0, p) * mix(1, 1.03, lin(t, 38, 43.4))
    hw, hh = (tgt[2] - tgt[0]) / 2 * s, (tgt[3] - tgt[1]) / 2 * s
    return (c[0] - hw, c[1] - hh, c[0] + hw, c[1] + hh), p


def mpt(t, u, v):
    b, _ = xm_box(t); return inside(b, S.r('reuse', 'dialog'), u, v)


def use_btn_box(t):
    ub = S.r('reuse', 'use_button')
    a = mpt(t, ub[0], ub[1]); b = mpt(t, ub[2], ub[3]); return (a[0], a[1], b[0], b[1])


def s_xair(t):
    f = background(t)
    pl = S.plate('reuse')
    e = enter(t, 37.0, 1.0)
    cam = ccam('reuse', 1300, 560, 1500, rx=6, ry=12, dx=(1 - e) * 500)
    card(f, pl, cam, bright=0.55, alpha=e * 0.9, shadow=0.3)
    b, p = xm_box(t)
    if p > 0: draw_crop(f, pl, S.r('reuse', 'dialog'), b, clamp(p * 3), 14, 0.6, 0.0)
    text_block(f, t, 37.4, 42.7, 'left', 'reuse')
    if t > 38.6:
        ax = mpt(t, *S.p('reuse', 'aircraft_tag'))
        label_pill(f, L('reuse', 'aircraft_tag'), ax[0] - 40, ax[1] - 150, t, 38.7, 40.2, anchor=ax)
    btn = use_btn_box(t)
    hov = lift_amt(t, 41.0, 43.2)
    if hov > 0: stroke_rrect(f, btn, 6, MINT, 2.5, hov, glow=0.8)
    k = lin(t, 41.5, 42.2)
    if 0 < k < 1: fill_rrect(f, btn, 6, MINT, 0.85 * (1 - ease_in(k, 2)))
    bc = ((btn[0] + btn[2]) / 2, (btn[1] + btn[3]) / 2)
    cur(f, t, 40.3, 43.4, [(40.3, (1500, 950)), (41.2, (bc[0] + 4, bc[1] + 4))], 41.5)
    click_ring(f, bc[0], bc[1], t, 41.5)
    if t > 41.6: label_pill(f, L('reuse', 'use_button'), btn[0] - 20, btn[3] + 60, t, 41.65, 42.7, align='right')
    return f


# ================================================================ S7 GENERAL COMMENT 42.8 - 46.8
def cam_gen(t):
    e = enter(t, 42.9, 1.0)
    return ccam('general', 1250, 560, 1000, zmul=mix(0.92, 1.0, e))


def s_gen(t):
    f = background(t)
    pl = S.plate('general'); cam = cam_gen(t)
    card(f, pl, cam)
    text_block(f, t, 43.1, 46.1, 'left', 'general')
    typed = T['general']['typed_text']
    n = int(clamp((t - 43.9) / 0.036, 0, len(typed)))
    sb = screen_box(cam, S.r('general', 'comment_placeholder'))
    if t >= 43.8:
        fill_rrect(f, (sb[0] - 4, sb[1] - 2, sb[2], sb[3] + 2), 3, fsample(f, (sb[2] + 20, sb[1], sb[2] + 90, sb[3])), 1)
        fs = (sb[3] - sb[1]) * 0.62
        tw = text(f, typed[:n], 'inter400', fs, sb[0] + 6, (sb[1] + sb[3]) / 2, INK, 1.0) if n else 0
        if (t * 2.5) % 1 < 0.6: capsule(f, (sb[0] + 10 + tw, sb[1] + 6), (sb[0] + 10 + tw, sb[3] - 6), 2, INK, 1)
    cb = screen_box(cam, S.r('general', 'create_button'))
    k = lin(t, 46.05, 46.5)
    if k > 0: fill_rrect(f, cb, 10, MINT, 0.7 * (1 - k))
    cc = ((cb[0] + cb[2]) / 2, (cb[1] + cb[3]) / 2)
    cur(f, t, 45.3, 46.8, [(45.3, (1350, 700)), (45.95, (cc[0] + 4, cc[1] + 4))], 46.05)
    click_ring(f, cc[0], cc[1], t, 46.05)
    return f


# ================================================================ S8 MY COMMENTS 46.2 - 53.0
def cam_mine(t):
    e = enter(t, 46.8, 1.0)
    return ccam('mine', 690, 560, 1120, rx=mix(-4, 2, e), ry=mix(-16, -8, e), zmul=mix(0.95, 1.0, e) * mix(1, 1.04, lin(t, 47, 53)))


def s_mine(t):
    f = background(t)
    pl = S.plate('mine'); cam = cam_mine(t)
    la, lb = lift_amt(t, 48.0, 50.0), lift_amt(t, 50.1, 52.2)
    rA, rB = S.r('mine', 'responses_columns'), S.r('mine', 'task_columns')
    card(f, pl, cam, dim=0.55 * max(la, lb), spot=rA if t < 50.05 else rB)
    text_block(f, t, 47.0, 52.2, 'right', 'mine', size=54)
    bx, _ = liftout(f, pl, cam, rA, fit_box(rA, 690, 560, 960), t, 48.0, 50.0)
    if bx: label_pill(f, L('mine', 'responses_columns'), bx[0] + 20, bx[3] + 50, t, 48.35, 49.6)
    bx, _ = liftout(f, pl, cam, rB, fit_box(rB, 700, 560, 560), t, 50.1, 52.2)
    if bx: label_pill(f, L('mine', 'task_columns'), bx[0] + 10, bx[3] + 50, t, 50.45, 51.8)
    return f


# ================================================================ S9 HEATMAP 52.3 - 61.0
# Treemap-shaped wipe (unit-square layout + colours, independent of the screenshot)
BLOCKS = [((0.001, 0.003, 0.492, 0.278), (0.80, 0.13, 0.10)), ((0.001, 0.278, 0.411, 0.546), (0.72, 0.12, 0.09)),
          ((0.003, 0.546, 0.279, 0.998), (0.68, 0.14, 0.08)), ((0.279, 0.546, 0.491, 0.998), (0.78, 0.50, 0.10)),
          ((0.492, 0.009, 0.760, 0.294), (0.80, 0.75, 0.12)), ((0.760, 0.009, 0.998, 0.297), (0.72, 0.78, 0.12)),
          ((0.411, 0.278, 0.771, 0.546), (0.78, 0.72, 0.10)), ((0.771, 0.297, 0.998, 0.546), (0.62, 0.78, 0.13)),
          ((0.492, 0.546, 0.635, 0.798), (0.38, 0.75, 0.12)), ((0.635, 0.546, 0.763, 0.798), (0.36, 0.72, 0.12)),
          ((0.492, 0.798, 0.631, 0.998), (0.30, 0.70, 0.12)), ((0.631, 0.798, 0.763, 0.998), (0.30, 0.68, 0.12)),
          ((0.763, 0.546, 0.864, 0.757), (0.33, 0.72, 0.14)), ((0.864, 0.546, 0.998, 0.757), (0.35, 0.70, 0.14)),
          ((0.763, 0.757, 0.998, 0.998), (0.30, 0.66, 0.14))]
HOT_T = [54.2, 54.8, 55.4]


def cam_heat(t):
    e = enter(t, 52.9, 1.0)
    return ccam('heatmap', 1240, 570, 1220, zmul=mix(1.06, 1.0, e) * mix(1, 1.04, lin(t, 53, 61)))


def s_heat(t):
    f = background(t)
    pl = S.plate('heatmap'); cam = cam_heat(t)
    lt = lift_amt(t, 56.0, 58.6)
    hot, k = None, 0
    for i, t0 in enumerate(HOT_T):
        if t0 <= t < t0 + 0.6: hot, k = S.r('heatmap', f'hot_{i + 1}'), lin(t, t0, t0 + 0.6)
    card(f, pl, cam, dim=max(0.45 if hot else 0, 0.55 * lt), spot=hot, hole=bool(hot) and lt < 0.01, spot_r=4)
    if hot: stroke_rrect(f, screen_box(cam, hot), 4, WHITE, 3, math.sin(math.pi * k), glow=0.9)
    text_block(f, t, 53.3, 60.2, 'left', 'heatmap', size=52)
    rT = S.r('heatmap', 'tooltip')
    bx, x = liftout(f, pl, cam, rT, fit_box(rT, 1260, 560, 820), t, 56.0, 58.6, radius=10)
    if bx:
        rb = S.r('heatmap', 'tooltip_bars')
        p0 = inside(bx, rT, rb[0], rb[1]); p1 = inside(bx, rT, rb[2], rb[3])
        kk = ease_out_expo(lin(t, 56.45, 57.5))
        if kk < 1 and x > 0.2:    # bars grow: a cover retracts upward
            fill_rrect(f, (p0[0], p0[1], p1[0], mix(p1[1], p0[1], kk)), 0, np.array([0.075, 0.085, 0.09], np.float32), 1.0)
        label_pill(f, L('heatmap', 'tooltip'), bx[0] + 10, bx[3] + 52, t, 56.6, 58.2)
    return f


def blocks_wipe(fa, fb, t, t0, t1):
    x = lin(t, t0, t1)
    out = fa.copy() if x < 0.5 else fb.copy()
    for i, (b, col) in enumerate(BLOCKS):
        bx = (b[0] * W, b[1] * H, b[2] * W, b[3] * H)
        d = (i % 5) * 0.035 + (i // 5) * 0.02
        s = ease_out_expo(lin(x, d, d + 0.3)) if x < 0.5 else 1 - ease_in_expo(lin(x, 0.5 + d, 0.5 + d + 0.3))
        if s <= 0: continue
        cx, cy = (bx[0] + bx[2]) / 2, (bx[1] + bx[3]) / 2
        hw, hh = (bx[2] - bx[0]) / 2 * s, (bx[3] - bx[1]) / 2 * s
        fill_rrect(out, (cx - hw + 3, cy - hh + 3, cx + hw - 3, cy + hh - 3), 10, np.array(col, np.float32) * 0.92, 1.0)
    return out


# ================================================================ S10 SIGN-OFF EMAIL 60.3 - 65.4
def cam_mail(t):
    e = enter(t, 60.4, 1.0)
    return ccam('email', 1250, 560, 1060, rx=mix(6, 2, e), ry=mix(16, 7, e), zmul=mix(0.92, 1.0, e))


def clara_pill_box(): return fit_box(S.r('tasks', 'ask_clara'), 1500, 880, 300)


def s_mail(t):
    f = background(t)
    pl = S.plate('email'); cam = cam_mail(t)
    la = lift_amt(t, 61.6, 63.2)
    rA = S.r('email', 'subject_row')
    ex = ease_in_expo(lin(t, 64.2, 64.7))
    card(f, pl, cam, dim=max(0.55 * la, 0.5 * ex), spot=rA)
    text_block(f, t, 60.8, 64.3, 'left', 'email')
    bx, _ = liftout(f, pl, cam, rA, fit_box(rA, 1250, 250, 1150), t, 61.6, 63.2)
    if bx: label_pill(f, L('email', 'subject_row'), bx[0] + 20, bx[3] + 50, t, 61.9, 62.9)
    sb = screen_box(cam, S.r('email', 'send_button'))
    k = lin(t, 63.8, 64.3)
    if 0 < k < 1: fill_rrect(f, sb, 10, MINT, 0.6 * (1 - k))
    sc = ((sb[0] + sb[2]) / 2, (sb[1] + sb[3]) / 2)
    cur(f, t, 63.0, 64.3, [(63.0, (1500, 900)), (63.65, (sc[0] + 4, sc[1] + 4))], 63.8)
    click_ring(f, sc[0], sc[1], t, 63.8)
    p = ease_back(lin(t, 64.3, 64.65), 1.6)
    if p > 0:             # the Ask Clara pill from the task list becomes the next transition
        reg = S.r('tasks', 'ask_clara'); b = fit_box(reg, 1500, 880, 300 * p)
        draw_crop(f, S.plate('tasks'), reg, b, 1.0, (b[3] - b[1]) / 2, 0.5, 0.7)
    return f


# ================================================================ S11 CLARA 64.7 - 70.0
def cam_clara(t):
    e = enter(t, 64.9, 0.9)
    return ccam('clara', 1320, 560, 560, zmul=mix(0.94, 1.0, e))


def s_clara(t):
    f = background(t)
    pl = S.plate('clara'); cam = cam_clara(t)
    card(f, pl, cam)
    if 'bub' not in _cache:
        rr = [int(v) for v in S.r('clara', 'bubble_background')]; img = pl.levels[0][1]
        _cache['bub'] = img[rr[1]:rr[3], rr[0]:rr[2], :3].reshape(-1, 3).mean(0)
    sugg = sorted([k for k in S.cfg['clara']['regions'] if k.startswith('suggestion_')], key=lambda s: int(s.split('_')[1]))
    for i, sk in enumerate(sugg):
        k = ease_back(lin(t, 65.9 + 0.18 * i, 66.25 + 0.18 * i), 1.8)
        reg = S.r('clara', sk); sb = screen_box(cam, reg)
        if k < 1:
            fill_rrect(f, sb, 2, _cache['bub'], 1.0)
            if k > 0:
                cx, cy = (sb[0] + sb[2]) / 2, (sb[1] + sb[3]) / 2
                hw, hh = (sb[2] - sb[0]) / 2 * k, (sb[3] - sb[1]) / 2 * k
                bb = (cx - hw, cy - hh, cx + hw, cy + hh)
                draw_crop(f, pl, reg, bb, 1.0, (bb[3] - bb[1]) / 2, 0.0, 0.0)
    hi = int(T['clara'].get('highlight_suggestion', 3))
    hb = screen_box(cam, S.r('clara', f'suggestion_{hi}'))
    hv = lift_amt(t, 67.6, 69.3)
    if hv > 0: stroke_rrect(f, (hb[0] - 3, hb[1] - 3, hb[2] + 3, hb[3] + 3), (hb[3] - hb[1]) / 2 + 3, MINT, 2.5, hv, glow=0.8)
    if t > 67.5: label_pill(f, L('clara', 'suggestion'), hb[0] - 60, hb[1] - 70, t, 67.65, 69.0, align='right',
                            anchor=(hb[0] - 3, (hb[1] + hb[3]) / 2))
    text_block(f, t, 65.1, 69.1, 'left', 'clara')
    return f


# ================================================================ S12 OUTRO 69.2 - 78
def tile_layout():
    keys = T['outro']['mosaic']
    cols, rows = 4, 3; tw, th = 520, 300; gx, gy = 40, 40
    ox = W / 2 - (cols * tw + (cols - 1) * gx) / 2; oy = H / 2 - (rows * th + (rows - 1) * gy) / 2
    out, k = [], 0
    for r in range(rows):
        for c in range(cols):
            if k >= len(keys): break
            if r == 1 and c in (1, 2): continue          # centre hole for the words
            out.append((keys[k], (ox + c * (tw + gx), oy + r * (th + gy), ox + c * (tw + gx) + tw, oy + r * (th + gy) + th)))
            k += 1
    return out


def s_outro(t):
    f = background(t)
    O = T['outro']
    col = ease_in_expo(lin(t, 72.4, 73.0))
    drift = lin(t, 69.2, 73.0)
    for i, (key, b) in enumerate(_cache['tiles']):
        p = ease_back(lin(t, 69.3 + 0.06 * i, 69.8 + 0.06 * i), 1.3)
        if p <= 0 or col >= 1: continue
        pl = S.plate(key)
        cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2
        cx = mix(W / 2 + (cx - W / 2) * mix(1.0, 1.08, drift), W / 2, col); cy = mix(H / 2 + (cy - H / 2) * mix(1.0, 1.08, drift), H / 2, col)
        tw, th = (b[2] - b[0]) * p * (1 - col * 0.9), (b[3] - b[1]) * p * (1 - col * 0.9)
        ar = pl.w / pl.h; tar = tw / max(th, 1)
        rw, rh = (pl.h * tar, pl.h) if ar > tar else (pl.w, pl.w / tar)
        top = pl.h * 0.05 if key == 'clara' else 0
        draw_crop(f, pl, (pl.w / 2 - rw / 2, top, pl.w / 2 + rw / 2, rh), (cx - tw / 2, cy - th / 2, cx + tw / 2, cy + th / 2),
                  1 - col, 14, 0.5, 0.0, bright=0.8)
    words = O['words']
    for i, w in enumerate(words):
        t0 = 70.5 + 0.5 * i
        p = ease_back(lin(t, t0, t0 + 0.2), 2.0)
        q = lin(t, t0 + 0.5, t0 + 0.55) if i < len(words) - 1 else ease_in(lin(t, 72.4, 72.8))
        if p > 0 and q < 1:
            text(f, w, 'inter800', 76 * mix(1.25, 1.0, p), W / 2, H / 2, MINT if i == len(words) - 1 else WHITE, 1 - q, 'center')
    if t >= 72.8:                           # end card
        p2 = ease_io_expo(lin(t, 72.8, 73.4))
        cx, cy = W / 2, H / 2 - 40
        w0, h0 = mix(40, 860, p2), mix(40, 260, p2)
        box = (cx - w0 / 2, cy - h0 / 2, cx + w0 / 2, cy + h0 / 2)
        fo = 1 - ease_in(lin(t, 77.0, 77.9), 2)
        shadow_rrect(f, box, 30, 0.5 * fo, 40, 24)
        fill_rrect(f, box, 30, PANEL, fo, glow=0.25 * (1 - p2), glow_color=MINT)
        stroke_rrect(f, box, 30, MINT, 1.6, 0.55 * fo)
        if t >= 73.2: logo(f, t, 73.2, box, fo)
        words_in(f, O['end_line'], 'inter600', 30, W / 2, cy + 200, t, 74.0, None, MINT, 'center', tracking=2)
        text(f, O['credit'], 'inter600', 18, W / 2, 1000, SUB, fade(t, 74.8, 77.9, 0.6, 0.9) * fo, 'center', tracking=8)
    return f


# ================================================================ timeline
SCENES = [('intro', 0.0, 5.0, s_intro), ('depts', 5.0, 11.0, s_depts), ('tasks', 10.2, 18.8, s_tasks),
          ('hist', 18.2, 23.6, s_hist), ('review', 23.0, 31.3, s_review), ('thread', 30.7, 37.6, s_thread),
          ('xair', 37.0, 43.4, s_xair), ('gen', 42.8, 46.8, s_gen), ('mine', 46.2, 53.5, s_mine),
          ('heat', 52.3, 61.0, s_heat), ('mail', 60.3, 65.4, s_mail), ('clara', 64.7, 69.8, s_clara),
          ('outro', 69.2, 78.01, s_outro)]


def _push(a, b, x, horizontal=True):
    out = np.empty_like(a)
    if horizontal:
        sh = int(W * x); out[:, :W - sh] = a[:, sh:]
        if sh > 0: out[:, W - sh:] = b[:, :sh]
        if 0 < sh < W: fill_rrect(out, (W - sh - 3, 0, W - sh + 3, H), 0, MINT, 0.9)
    else:
        sh = int(H * x); out[:H - sh] = a[sh:]
        if sh > 0: out[H - sh:] = b[:sh]
        if 0 < sh < H: fill_rrect(out, (0, H - sh - 3, W, H - sh + 3), 0, MINT, 0.9)
    return out


def trans(t):
    """Frame for t if it falls inside a transition, else None."""
    FULL = (-60, -60, W + 60, H + 60)
    if 10.2 <= t < 11.0:          # last department pill grows into the task list
        b = _cache['dbox'][-1]
        return shape_reveal(s_depts(t), s_tasks(t), lin(t, 10.2, 11.0), b, full_box((b[0] + b[2]) / 2, (b[1] + b[3]) / 2),
                            PILL_H / 2, 40, fill=UI_GREEN)
    if 18.2 <= t < 18.8:          # history icon -> circle iris
        hp = cam_tasks(18.2).project([S.p('tasks', 'history_icon')])[0]
        return shape_reveal(s_tasks(t), s_hist(t), lin(t, 18.2, 18.8), (hp[0] - 16, hp[1] - 16, hp[0] + 16, hp[1] + 16),
                            full_box(hp[0], hp[1], 1.0), 16, 99999)
    if 23.0 <= t < 23.6:          # Go pill expands
        gb = go_box()
        return shape_reveal(s_hist(t), s_review(t), lin(t, 23.0, 23.6), gb, FULL, (gb[3] - gb[1]) / 2, 40, fill=MINT_D)
    if 30.7 <= t < 31.3:          # chat bubble -> circle iris
        cp = cam_review(30.7).project([S.p('review', 'chat_icon')])[0]
        return shape_reveal(s_review(t), s_thread(t), lin(t, 30.7, 31.3), (cp[0] - 18, cp[1] - 18, cp[0] + 18, cp[1] + 18),
                            full_box(cp[0], cp[1], 1.0), 18, 99999)
    if 37.0 <= t < 37.6:
        return _push(s_thread(t), s_xair(t), ease_io_expo(lin(t, 37.0, 37.6)), True)
    if 42.8 <= t < 43.4:          # "Use this comment" button expands
        return shape_reveal(s_xair(t), s_gen(t), lin(t, 42.8, 43.4), use_btn_box(42.8), FULL, 6, 40, fill=MINT)
    if 46.2 <= t < 46.8:
        return _push(s_gen(t), s_mine(t), ease_io_expo(lin(t, 46.2, 46.8)), False)
    if 52.3 <= t < 53.5:          # treemap blocks
        return blocks_wipe(s_mine(t) if t < 52.9 else None, s_heat(t) if t >= 52.9 else None, t, 52.3, 53.5)
    if 60.3 <= t < 61.0:
        c = (1260, 560)
        return shape_reveal(s_heat(t), s_mail(t), lin(t, 60.3, 61.0), (c[0] - 80, c[1] - 40, c[0] + 80, c[1] + 40), FULL, 12, 40)
    if 64.7 <= t < 65.4:          # Ask Clara pill expands
        pb = clara_pill_box()
        return shape_reveal(s_mail(t), s_clara(t), lin(t, 64.7, 65.4), pb, FULL, (pb[3] - pb[1]) / 2, 40, fill=MINT_D)
    if 69.2 <= t < 69.8:
        x = ease_io_expo(lin(t, 69.2, 69.8))
        a = s_clara(t); b = s_outro(t)
        sc = mix(1.0, 0.85, x)
        M = np.float32([[sc, 0, W / 2 * (1 - sc)], [0, sc, H / 2 * (1 - sc)]])
        return cv2.warpAffine(a, M, (W, H), borderMode=cv2.BORDER_REFLECT) * (1 - x) + b * x
    return None


def build_cues():
    SFX.clear()
    N = len(T['departments']['names'])
    cue('pop', 0.35, .6); cue('whoosh', 1.0, .5); cue('hit', 2.2, 1.0); cue('whoosh', 4.35, .6)
    for i in range(N): cue('tick', 6.0 + 0.25 * i, .8)
    for i in range(N): cue('check', 8.0 + 0.2 * i, .6)
    cue('whoosh', 10.2, .8)
    cue('pop', 12.4, .8); cue('pop', 14.45, .8); cue('click', 18.0, 1); cue('whoosh', 18.2, .8)
    for i in range(6): cue('tick', 19.8 + 0.3 * i, .7)
    cue('pop', 21.9, .8); cue('pop', 22.5, .9); cue('click', 22.95, 1); cue('whoosh', 23.0, .9)
    cue('pop', 24.4, .8); cue('pop', 26.35, .8)
    for i in range(9): cue('tick', 28.6 + 0.18 * i, .6)
    cue('click', 30.6, 1); cue('whoosh', 30.7, .8)
    cue('pop', 31.7, .5); cue('pop', 32.2, .5); cue('pop', 32.7, .5); cue('pop', 33.3, .8)
    for i in range(6): cue('tick', 33.7 + 0.16 * i, .5)
    cue('pop', 35.2, .8); cue('whoosh', 37.0, .8)
    cue('pop', 37.5, .9); cue('pop', 38.7, .7); cue('click', 41.5, 1); cue('success', 41.55, .8); cue('whoosh', 42.8, .8)
    typed = T['general']['typed_text']
    for i in range(0, len(typed), 2): cue('key', 43.9 + i * 0.036, .35)
    cue('click', 46.05, 1); cue('whoosh', 46.2, .8)
    cue('pop', 48.0, .8); cue('pop', 50.1, .8); cue('whoosh', 52.3, 1.0)
    for i in range(8): cue('block', 52.35 + 0.05 * i, .4)
    for tt in HOT_T: cue('tick', tt, .8)
    cue('pop', 56.0, .9); cue('rise', 56.4, .6); cue('whoosh', 60.3, .8)
    cue('pop', 61.6, .8); cue('click', 63.8, 1); cue('success', 63.85, .7); cue('pop', 64.3, .8); cue('whoosh', 64.7, .9)
    for i in range(6): cue('tick', 65.9 + 0.18 * i, .6)
    cue('pop', 67.6, .8); cue('whoosh', 69.2, .9)
    for i in range(len(T['outro']['words'])): cue('hit2', 70.5 + 0.5 * i, .8)
    cue('rise', 72.0, 1.0); cue('hit', 73.0, 1.0)


def init(screens, story):
    global S, T
    S, T = screens, story
    _cache.clear()
    _cache['dbox'] = dept_boxes()
    _cache['tiles'] = tile_layout()
    build_cues()


def render(t):
    """RGB uint8 frame (1080, 1920, 3) for time t in seconds."""
    f = trans(t)
    if f is None:
        for n, a, b, fn in SCENES:
            if a <= t < b:
                f = fn(t); break
        else:
            f = background(t)
    fl = 0.0
    for kind, tc, g in SFX:
        if kind == 'hit' and 0 <= t - tc < 0.5: fl = max(fl, 0.18 * g * math.exp(-(t - tc) * 9))
    g = min(1.0, t / 0.5) * min(1.0, max(0.0, (DUR - t) / 0.6))
    return finish(f * g, t, fl)
